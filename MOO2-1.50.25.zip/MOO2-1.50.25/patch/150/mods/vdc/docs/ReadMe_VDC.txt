Welcome to the ULTIMATE ENTERTAINMENT MOD for MoO2 � The so-called "Very Difficult Choice Mod" VDC X12 V72 B5 /Updated 2025-12-13

Installing the mod: 
The 'X' version of VDC Mod uses the 1.50 patch to run. X12 corresponds to 1.50.24 version  of the patch. VDC is now launched as a separate config run by 1.50 patch executable ORION150.EXE.

How to Install: 

- Install or COPY MoO2 to new directory

- Install the 1.50 patch (extract it to the root folder of the game overwriting the exsiting files); the patch can be found at: http://moo2mod.com/#download
  Don't forget to back up your build lists! if you already had run the patch before, otherwise on new extraction of the patch they will be overwritten!

- Extract VDC installation to newly created MoO2 directory overwriting the existing files; Note that contents of the VDC folder, which is present in the installation package shouldn't be moved from there to the root folder of the game; that folder should stay in root folder like it is;
             
- Configure ENABLE.CFG which is in the folder named 150 located in the root moo2 folder after installing 1.50 patch by putting: enable VDC-GM3NR60; or enable VDC-GM3NR55; or enable VDC-REG; AND corresponding map: enable MAP5_VDCGM3; or  enable MAP5_VDCREG;
  also make sure to put semicolon at the end of each line.

- Configure VDCGM3NR60.CFG or VDCREG.CFG for command line, interface options and ground rules (located in 150/mods/VDC folder of the the installation package); save after you make changes;

- Run VDC mod via ORION150.EXE (http://masteroforion2.blogspot.com/2006/05/dosbox-guide.html);

There are THREE different settings to run the mod: VDC-GM3NR60 and VDC-GM3NR55 use map GM3 standard multiplayer map (goodmap3 map provides 3 planets in each star system; gas giants and asteroid belts were removed), 
while VDC-REG uses map generation close to original map.


If you would like to share any ideas on the mod plz leave your comments here: https://discord.com/channels/471752088913707018/473451267675389952

Yours sincerely,

IR
the creator of 'VDC mod'


Special thanks to TF8, who contributed to further improving of the VDC mod and for creating mapgenerator program, which enhances the gameplay. For more details about mapgenerator program see the following link: http://masteroforion2.blogspot.com/2009/03/map-generator.html
Taking opportunity, I want to express the great thanks to Andrey Tyukov, who was collaborating with me for five years and by the help of whom it became possible to release the revolutionary 42a update, where it became possible to fix the stealth issue, android costs, cryogen.exe (for uncreative) and many other things;
Great thanks to Nirran who made very helpful tool to work with 1.40 patch executable, which I have been using for a long time;
Greatest thanks to Alex, Darza and Rocco who created the 1.50 patch, which greatly enhances the gameplay and includes revolutionary bug fixes and changes; see the reference in the patch manual and in 'Comprehensive List of Bug Fixes and Rule Changes of 1.5 Patch over VDC Mod';
Big thanks to Epirasque, who contributed to VDC mod with a lua script for HVG race, included in this mod;



List of updates (version/updated):



VDC X12 V72 B5 /Updated 2025-12-13

- Feudal Government initial ship building discount decreased back to 27% and science penalty decreased back to 25%;
  discount on Confederation level is kept at 33%, while science penalty remaines at -15%;
- Trade Goods BC output for ordinary races increased from 75% to 100%; expert trader keeps 150% bonus;
- Race picks altered:
    Aquatic increased back from 6 to 7;
   -25 Attack decreased  from -6 to -7;
- Increased Star Bases and ground installations range by 6 squares: it affects all beams and proton torps, e.g. proton torps 
  both on starbase and missile base will hit enemy ships at 6 squares longer distance; (defensive_range_bonus = 2;)  


VDC X12 V72 B4 /Updated 2025-10-03

- Race picks altered:
  Repulsive increased from -5 to -6;
  Poor hw decreased from   -4 to -3;
  Unification increased from 18 to 19;
  Lithovore increased from 23 to 24;


VDC X12 V72 B3 /Updated 2025-09-19

- Race picks altered:
  Max negative points increased from -12 to -13;
  Uncreative and -BC get -13;
  Cybernetic increased from 4 to 5;
  HVG increased from 4 to 5;
  +40 defense increased from 4 to 5;
  Poor HW increased from -3 to -4;
  Aquatic decreased from 7 to 6;
- Anti-missile rockets base space consumption decreased from 12 to 10;



VDC X12 V72 B2 /Updated 2025-08-31

- Feudal Government initial ship building discount increased from 27 to 30%; discount on confederation reduced from 38% to 33%;
- Feudal Government science penalty increased from 25% to 30%;
- Cruiser hull cost decreased from 600 to 580 BC;
- Map generation both for GM3 and regular(REG) map updated: large ultra riches get normal gravity now;
- Post Warp game setup revised - tachyon scanner and tachyon communications were removed from known techs, instead pollution processor and merculite missile was added;
  strange bug was noticed - in postwarp setup 'Large Scale Construction' tech field visually disappears from the tech tree when checking the tech advance, but it will appear once you research the previous level;


VDC X12 V72 B1 /Updated 2025-08-30

- Astro Construction tech field research cost decreased from 2750 to 2500 rps;
- Cybertronics tech field research cost decreased from 4500 to 3750;
- Quantum Detonator is moved back to Hyperdimensional Fission tech field; Siron leader keeps QD technology;
- Planetary Radiation Shield building cost increased from 80 to 100 BC;
- Planetary Flux Shield building cost decreased from 200 to 150 BC;
- Planetary Barrier Shield building cost decreased from 500 to 300 BC;
- Battle Station building cost decreased from 1500 to 1250 BC;
- Corrected and improved tech descriptions;
- Adjusted AI building priority list;



VDC X12 V71 B3 /Updated 2025-08-11

- Warp Interdictor building cost decreased from 1200 to 1000 BC;
- Doom Star Hull cost increased back to 6500 (was made 6250 in - X12-V70-B1);
- Pulsar damage and space consumption restored to old values: damage 10-16 (was made 10-20) and space 25 (was made 20 in - X11 V68 B5);



VDC X12 V71 B2 / Updated 2025-07-17

- Race picks altered:
  +35 starting positive picks instead of +34;
  -0.5 Food -4 (was -5);
  Tolerant  22 (was 21);
  Lithovore 23 (was 22);
  Democracy 12 (was 11);
- AI Stock races adjusted accordingly - check .xls file for details;
- VDCREG.cfg was set fixed_research_cost = 0; i.e. random roll for tech breakthrough re-enabled; set =1 for no random;  



VDC X12 V71 B1 / Updated 2025-06-28

- Cybertronichs tech field research cost increased from 3500 to 4500 rps;
- High energy Distribution research cost increased from 3500 to 5000 rps;
- Hyperdimensional Fission research cost increased from 5000 to 6500 rps;
- Quantum Detonators were moved from Hyperdimensional Fission tech feild to Matter-Energy Conversion tech field;
- Siron leader was added Quantum Detonator tech;
- Cost of asterisk famous was slightly reduced;



VDC X12 V70 B2 / Updated 2025-05-13

- Repulsive initial leader hire chance penalty completely removed (is same as non-repulsive now);
- Level 5 leaders experience points set as 330 and 420 for level 6;
- Charismatic race hiring chance bonus increased from 32 to 36;
- Some leaders stats upgraded, check .xls file for details;
- Star Fortress building cost further reduced to 2500;
- Core Waste Dumps upkeep reduced from 8 to 6 BC;
- Jump Gate bonus increased from 4 to 5 parsecs;
- Reflection Field strength increased from 20 to 24;



VDC X12 V70 B1 / Updated 2025-01-28

- VDCGM3 map generator updated: planet specials chances slightly increased and probabilities of specials revised: 
   gold - 10% (was 9), natives - 12% (was 9%), pirate stash and debris - 4% (was 3%), artifacts 7% (was 5%);
- Quantum Fields research cost reduced from 3750 to 3500;
- Temporal Fields research cost reduced from 7500 to 6500;
- Star Fortress space reduced from 5760 to 5080 and building cost reduced from 3000 to 2650;
- Battlestation space increased from 2300 to 2520;
- Starbase space increased from 1150 to 1260;
- Starbases weapon allocation percentage changed from 32-15-11-42 to 30-15-10-45 from hvy beams to missiles;
- Doom Star Hull cost reduced from 6500 to 6250;
- Artemis System Net building cost reduced from 11000 to 10000;
- Ground Battery space increased from 770 to 800 for hvy beams;
- Proton torpedo range increased from 9 to 10;
- Interceptors base speed increased from 14 to 16 and number of shots from 4 to 5;
- Race picks altered:
   tolerant decreased back to 21;
   warlord increased from 4 to 5;


VDC X12 V69 B4 / Updated 2024-11-18

- Bombers base speed increased by 2 (was 10, became 12); now it is same with Heavy Fighters;
- Map generator updated - increased base capacity for huge from 27 to 28, and slightly modified some climates % of the total capacity; check .xls file for details;
- Advanced City Planning capacity bonus was decreased from +5 to +4;
- Marine barracks was removed maintenance cost;
- Race picks costs altered:
   tolerant increased from 21 to 22;
   stock races adjusted accordingly;
- Added a script for the HVG race, large abundant swamp in home system becomes huge; 

- VDCREG gets bonuses as of VDCGM3NR60 (psionics at 20, unification production +60, democracy starting morale +10); VDCGM3NR55 keeps lowered bonuses;
- VDCREG starts to use fixed research cost - no more random roll scientific breakthrous;
- Changed required building for terraforming toxic into barren (Atmosphere Renewer to Core Waste Dumps);



VDC X12 V69 B3 / Updated 2024-07-26

- Added anti-missile rockets base hit chance parameter supported by 1.50.23 version of the patch; B3 build is no longer compatible with 1.50.22 version;
- Anti-missile rockets chance-to-hit increased by 3%;
- Map generation both for gm3 and regular(REG) map updated: large riches get normal gravity now;
- LUA script for HVG races updated - now only races which start with large homeworld will get size increase to huge;
- Creative race pick cost decreased from 13 to 12;
- Psilon stock race was added expert trader pick;


VDC X12 V69 B2 / Updated 2024-06-26

- Scoutlab research bonus & space consumption for Battleship and Cruiser rolled back to previous values;
- Plasma Physics field cost increased from 3000 to 3500 for all versions;
- Plasma Cannon damage increased from 22-45 to 30-45 (minimal damage was increased);
- Particle beam damage increased from 22-42 to 22-44;


VDC X12 V69 B1 / Updated 2024-05-09

- Galactic Economics tech field cost reduced from 12.5k to 10k for NR version;
- Plasma Physics field cost reduced from 3750 to 3000 for all versions;
- Scoutlab research bonus for Battleship and Cruiser class decreased from 37 and 24 to 33 and 22 rps respectively; slightly decreased space consumption;
- Plasma torpedoes space reduced from 65 to 63;
- Proton torpedo damage increased from 60 to 64;
- Emg mod's space reduced from +200% to +160%;
- Mass Drivers damage increased from 10 to 12;
- Gyro Destabilyzers damage increased back to 4-6;
- Blue Star chances increased from 6 to 7% for organic rich galaxy;
- Feudal cost reduced from -8 to -9;
- Stock races revised, check .xls file for details;


VDC X12 V68 B2 / Updated 2024-02-26

- Subterranean farm's output decreased back to +6 per building and building cost increased back to 120 BC;
- Missile base space increased from 656 to 800; building cost increased from 120 to 150;
- Ground batteries heavy beam space increased from 693 to 770;
- Star base space increased from 975 to 1150 and building cost from 450 to 500;
- Battlestation space increased from 2100 to 2300; building cost increased from 1400 to 1500;
- Battleship space increased from 434 to 450;
- Titan space increased from 941 to 950;
- Cruiser space increased from 288 to 300 and hull cost from 550 to 600;
- Frigate space increased from 57 to 60 and hull cost increased from 45 to 50;
- HVG race cost reduced back to 4 points;
- Tolerant cost increased from 20 to 21 points;



VDC X12 V68 B1 / Updated 2023-10-02

- Accommodation of VDC to 1.50.22 version of the patch; full list of changes can be found at: http://moo2mod.com/
new change:
- added an interface parameter print_research_value, which was set to 'remaining';

- Chances for grabbing tech on invasion from population was set to 6% of the number of pop (previously was made 0); 
- Feudal's ship building discount on Confederation level increased back to 38% (was made 35% before);
- Cost of android workers decreased from 100 to 75;
- Science serendipidity event delay set to 110 instead of 125 and  derelict event delay set to 115 instead of 100 for gm3 versions;
- Ion cannon space decreased from 20 to 18;
- Heavily armored mod of missiles space decreased from 25% to 20%;
- Cloaking device space consumption reduced; Cloaking field's space slightly increased for high-tier hulls;
- Battlestation building cost reduced from 1500 to 1400;
- Charismatic starting pool of leaders increased by 1 (+14 instead of +13);
- Overhaul of leaders table, modifying some leaders and leaders order - check .xls file for details;
- Some leader skill cost adjusted; 





VDC X11 V68 B5 / Updated 2023-08-23

- Corrected Psionics bonus for NR 55;
- Charismatic race bonus for the chance of a leader offer increased further from 30 to 32%;
- Cybernetic repair increased from 10% to 13%; repair rate of internal systems comprise now 75% of armor & structure repair (was 83%);
- Subterranean farms output increased from +6 to +7 food per building; building cost increased to 110 BC;
- Interceptors number of strikes increased from 4 to 5;
- Ion canon damage increased from 5-15 to 6-16;
- Pulsar damage increased from 1-16 to 1-20; space consumption reduced from 25 to 20;
- Autorepair unit space consumption reduced by 10%-15% for high-tier hulls;
- Emg mod space consumption reduced from +300% to +200%; 
- Tech capture chance on ground invasion increased from 16% to 20% of the number of buildings; chance of grabbing second tech is 1/2 of previous;
- Leaders skills cost revised;
- Some leaders stats updated, check .xls file for details;




VDC X11 V68 B4 / Updated 2023-07-10

- VDCGM3NR (No Random) - splits into two versions: NR55 and NR60. IN NR 55 unification's production bonus is 55%, democracy initial morale
  bonus is 5% and psionics morale bonus for dict and feudal is 15%; in NR 60 unification's production bonus is 60%, democracy initial morale
  bonus is 10% and psionics morale bonus is 20%;
- +2 food cost increased from 7 to 8 points;
- HVG cost increased from 4 to 5 points;
- bonus of charismatic chance of a leader offer increased from 27 to 30%;





VDC X11 V68 B3 / Updated 2023-05-22

- Required difference of spying total bonuses for stealing success was increased from 30 to 33;
- Feudal's initial ship building discount in NR version increased back to 25% (was 23%); now in all versions it is 25% on base and 35% Confederation level;
- Graviton beam was removed pd mod (it made interceptors too powerful);
- Corrected fusion bomb's damage (0-55 instead of 0-50);
- Updated eco weights sheet in .xls file;



VDC X11 V68 B2 / Updated 2023-04-05


- Dictatorship government was removed initial morale penalty; barracks on imperium level gives 20% morale bonus;
- Picks updated: +1 prod now costs 6 points, +2 prod - 12 points; +3 prod keeps 18 points; AI stock races updated to reflect this change;
- Pop growth bonuses increased: +65 and +85 instead of +60 and +80;
- corrected description of proton torpedo;
- corrected Jarred  leader tech;




VDC X11 V68 B1 / Updated 2023-03-28

- Matter-Energy conversion tech field cost was made 2500 for all versions (transporters and proton torpedo);
- Anti-missile rockets technology put on place on titanium armor (starting tech field in chemistry), while titanium armor becomes a known tech; base space consumption increased to 12;
- Unification's production bonus for NoRandom version made 60% again and 110% on galactic unification level;
- Frigate space increased by 5 and cost by 10;
- Fighter garrison number of bombers and heavy fighters increased by 1;
- Jarred leader was deprived of anti-missile rocket tech, instead he was given tachyon scanner;



VDC X11 V67 B10 / Updated 2023-03-10

- Map generator updated: special chances revised - natives get less chances, while chances for gold and gems slightly increased;
- Feudal initial ship discount was decreased from 25% to 23% again for NR version;
- Unification's production bonus for NoRandom version decreased back from 60% to 55% on base level and from 110% to 105% on galactic unification level; made same for all versions;
- Proton torpedoes range increased from 8 to 9; now comprises 27 squares (was 24);
- Battleship's and Titan space increased by 1 point;



VDC X11 V67 B9 / Updated 2023-02-24

- Mapgeneration for GM3 map updated: ultrariches were removed from white stars: unguarded ultrariches can now appear only in blue stars, which have low chances of appearing; med uriches recieve normal gravity;
- Mapgeneration for REG map updated: star spectral chances modified;
- Planet specials chances table was removed from the main config, it can be set in respective map config only;
- Feudal ship production discount was made 25% back; Confederation keeps 35% in NR and 40% in random version; research penalty was set to 30% for random version;
- Disctatorship initial moral penalty reduced from 20 to 10%, while barracks give 10% on base and 20% moral bonus on imperium level with no moral penalty (this is for NR version, random version keeps old setting);
- Democracy starting moral bonus increased from 5% to 10% for NR version; random version keeps 5%;
- Unification's production bonuses were made 55% and 105% for adv gov in random version; NoRandom keeps 60% and 110%;
- Neutron Blaster was removed pd mode; instead Graviton Beam was added it - this means fighters can now employ graviton beam, when it becomes available;
- Stock races updated: Trilar +1 food was swapped for HVG; Mrrshan gets expert trader for unused point;




VDC X11 V67 B8 / Updated 2023-02-01

- Accommodation of VDC to 1.50.20 version of the patch; full list of changes can be found at: http://moo2mod.com/
new change:
- send_natives command was added, and can be modified in the ground rules section of vdc config;

- Map geneator updated, enabling artifacts special for planets, which was previously removed due to bug on mirror map;
- Feudal ship production discount was reduced from 27% to 23%, and on Confederation level from 40% to 35%; research penalty was made 25% for all versions (was for NR only);
- Spying penalty for democracy reduced from -10 to -5; and it keeps 0 on federation;
- Spying roll (NR version) decreased back from 0-35 to 0-33; required difference for spying success set at 30 (same for sabotage);
- Number of spies bonus changed (NR version): 1-6 spies give +2 each, from 7 to 16 give +1 each and above 16 give 1/2 each (rounded up);
- Lucky Events delay revised: delay of serendipidity increased from t75 to t125 for VDCGM3 and VDCGM3-NR version;
- Scoutlab bonuses updated: now they comprise  1-6-24-37-75-200 respectively;
- Neutron blaster damage was increased from 6-16 to 8-18;
- Particle beam damage increase from 20-42 to 22-42;



VDC X10 V67 B7 / Updated 2022-010-14

- Unification production bonus made 60% again for all versions and 110% on Galactic Unification level;
- Spying agent penalty for democracy on advanced government level reduced from -5 to 0;
- Universal Antidote growth bonus is no longer cumulative with Microbiotics - rolled back to original behavior, i.e. the best bonus applies;
- Corrected leaders data, added telepath skill to Ailis;




VDC X10 V67 B6 / Updated 2022-09-19


- Unification production bonus for NoRandom version decreased back from 60% to 55% on base level and from 110% to 105% on galactic unification level;
- Unification food bonus for VDCGM3 (random version) and VDCREG increased from 55% to 60%; now all 3 versions have same bonus;
- Charismatic leader offer chance made +27 for all versions;
- Starting command points decreased from 8 to 6;
- Starbases command points increased: Starbase - 2; Battlestation - 4; Star Fortress - 6;
- Cruiser class ship's hull cost decreased from 650 to 550; base armor and structure points decreased from 35 to 30; 
- Scoutlab bonuses overhauled - new bonuses are: 1-6-23-38-85-200 (was 1-6-24-37-75-125);
- Neutron Blaster was added pd mode, so interceptors and heavy fighters can employ it;
- Stock race Alkari overhauled, check .xls file for details. 


VDC X10 V67 B5 / Updated 2022-06-04


- Update of the tech tree for No Random version: cost of Robotics increased back to 500; Cloning centers cost decreased from 300 to 250;
- VDCGM3 map generation change - added 10% chance of ultrarich planets appearing in Blue & White stars systems; additionally slightly increased chances of blue and white stars;
- Spying bonuses updated: random roll increased from 33 to 35; required difference for spying success decreased from 33 to 30;
- Telepathic race spying bonus increased back to +20;
- Subterranean farms building cost decreased from 120 to 100 BC;
- Cost of freighters decreased from 50 to 48 BC;
- Cost of scoutlabs for destroyer and frigate class ships reduced to zero;
- Script for Uncreative - added forcing spaceport in the tech tree in case of alien management center;




VDC X10 V67 B4 / Updated 2022-05-03

- Serendipidity lucky event's delay increased from t50 to t75;
- Diplomatic marriage/blunder event's delay increased to t150;
- script for HVG homewolrd increases homeworld size for any race now, not only lithovore;
- script for Uncreative - added forcing cloning centers  in the tech tree in case of subterenean farms;
- Microbiotics and Univeral Antidote growth bonus made cumulative;
- charismatic leader offer chance increased from +24 to +27 for NR version only;
- race cost altered - 
  Lithovore new cost  - 22 (was 24);
  corrected cost of lucky for VDCGM3 and VDCREG (should have been 2 points);




VDC X10 V67 B3 / Updated 2022-04-13

- Further update of the tech tree for No Random version: Robotics 400 (was 500); 
- Unification production bonus for NR version increased from 55% to 60% on base level and from 105% to 110% on galactic unification level;
- FF space increased by 1 more point;





VDC X10 V67 B2 / Updated 2022-04-08

- Further update of tech tree for No Random version: Positronics 1050 (was 1150); Cybertronics 3500 (was 3750); Anti-matter Fission 1500 (was 2000);
  Spaceport 300 (was 400);
- Feudal government research penalty was reduced from 30% to 25% for NR version;
- Unification gets base food bonus +60% instead if 55% for NR version;
- Democracy spying penalty restored back to -10 on base and -5 on federation level;
- Research lab sci bonus of the building was increased from 5 to 6 and galactic cybernet bonus was increased from 15 to 19 for NR version;
- Reintroduced back a script, which gives Lucky pick gold deposit for homeworld for any race except artifacts hw, while artifact hw 
  becomes ultra artifacts, i.e. gives +3 research instead of +2; cost of lucky increased from 1 to 2 points;
- Events rolls adjusted once again;
- FF and BB space was increased by 1 point;
- Starting command points increased from 7 to 8;
- Cost of scoutlabs for the ships descreased by about 50%;
- Gyro destabilyzer range decreased back from 6 to 5;




VDC X10 V67 B1 / Updated 2022-03-29

- Accommodation of VDC to 1.50.19 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
new changes:
- Amount of freighted population limit increase now works (it was meant to work in 1.50.18 but didn't work in fact);
- New parameter was introduced, which allows to fix research cost by removing tech rolls. All techs require additional 100% of nominal cost;
  this option was activated in VDCGM3NR (no random) version of vdc;  VDCGM3NR is launched by adding 'enable VDC-GM3NR;' line in ENABLE.CFG;
- Chances of grabbing technology on invasion planets can be modified in respective .cfg;
- Telepathic race can mindcontrol ship captured in combat multiple times after recapture by opponent; 
- Crystal monster was added one special. 
- Parameters for spying random rolls were added in config;

VDC changes:
- Tech tree was updated for no tech rolls version of the mod; the folowing tech fields were modified:
  Optronics - 130 rps (was 150), advanced engineering 70 (was 80),  advanced construction 130 (was 150), robotics 500(was 600), advanced chemistry 500
  (was 600), molecular compression 1050 (was 1150), molecular manipulation 3500 (was 3750),  macrogenetics 130 (was 150), artificial life 1050 (was 1150), 
  high energy distribution 3500 (was 3750), Teaching methods 3000 (was 3150), Galactic Economics 12500 (was 13500);
- Events roll changed with attempt to avoid bug;
- Some events got delay change;
- Spying mechanics was overhauled:  random roll was reduced from 0-100 to 0-33; invariable spying success at roll = 100 is no longer possible;
  each spy gives new bonus : number of spies 0-35 give +1 each; 36-63 give +1/2 each;
  required difference of total spying bonuses plus random minus defense for success was reduced to 33;
- Democracy government gets new spying penalty: -5 on base level and 0 on federation level;
- Telepathic race gets +15 spying bonus instead of +20 for NR version*;
- Chances for grabbing 1-4 technology from a planet on invasion were set to 16%; 8%; 5.33% and 4% from number of buildings, pop doesn't count anymore;
- Crystal was added Warp dissipator special;
- Number of stars for medium map were increased from 45 to 48 and for large map from 54 to 56;
- Cassandra was removed neural scanner technology; 




VDC X9 V66 B11 / Updated 2022-01-23

- Starting command points increased from 6 to 7;
- Amoeba gets class II shield (additionally 160 hp each side); 
- Fast missile racks space consumption slightly decreased, check .xls file for details;



VDC X9 V66 B10 / Updated 2022-01-17

- Eel's hp increased from 3500 to 4000;
- Crystal gets class II shield (additionally 160 hp each side); 




VDC X9 V66 B9 / Updated 2022-01-04

- Starting gold increased from 50 to 75 BC;
- Destroyer class base space increased from 125 to 130;
- Monsters got major change in their stats:
  Crystal gets 1 heavyy beam instead of 2 ordinary;
  Hydra gets 2 heavy beams instead of 3 ordinary;
  Dragon gets autofire mod for pd beams;
  Amoeba gets subspace teleporter instead of phase shifter;
  Monsters hp further updated, new hp is:
  Eel - 3500 (was 3200);
  Amoeba - 3200 (no change);
  Crystal - 4000 (was 3200);
  Dragon - 4000 (was 3200);
  Hydra - 4000 (was 3200);
- Monsters weapons damage increased:
  Crystal ray new damage 250-500 (was 150-350);
  Eel's caustic slime 150-150 (was 100-150);
  Amoeba's plasma flux 125-250 (was 100-200);
  Dragon's Phasor eye 5-15 (no change);
  Hydra's plasma breath 200-300 (was 160-280);
- Couple of leaders stats updated, check xls file for details;
- Race picks updated:
  Charismatic 4 (was 3);
  Cybernetic 4 (was 5);
  + 2 food 7 (was 8);
  Aquatic 7 (was 8);
  Democracy 11 (was 12);
- Stock AI races updated accordingly;


VDC X9 V66 B8 / Updated 2021-11-29


- Battlepods space for dd, ca, bb slightly increased;
- Monsters hp further updated, new hp is:
  Eel - 3000 (was 2700);
  Amoeba - 3200 (was 2800);
  Crystal - 3200 (was 3000);
  Dragon - 3200 (was 3000);
  Hydra - 3200 (was 3000);
  


VDC X9 V66 B7 / Updated 2021-11-23

- Charismatic race leaders hiring chance bonus decreased from 27 to 24;
- Repulsive race leaders hiring chance penalty decreased from 5 to 3;
- Bombers base production cost decreased from 30 to 20;

- Monsters hp updated, new hp is:
  Eel - 2800 (was 2500);
  Amoeba - 2800 (was 2600);
  Crystal - 3000 (was 2700);
  Dragon - 3000 (was 2700);
  Hydra - 3000 (was 2700);



VDC X9 V66 B6 / Updated 2021-05-24

- Gyro destabilyzer's space consumption decreased back from 25 to 19;
- Artifact planets were removed from VDCGM3 map, until mirror map bug gets fixed;
- Natives and Gold special chances slightly increased;



VDC X9 V66 B5 / Updated 2021-03-08

- Gyro destabilyzer's damage decreased from 4-6 to 4-5 per size class and space consumption increased from 19 to 25;
- Leaders skill costs revised once again;
- Spying technology success roll threshold increased from 75% to 80%;
- Events roll changed (there is a bug with events roll, trying to remove that bug);
- Monsters hp updated, new hp is:
  Eel - 2500 (was 2300);
  Crystal - 2700 (was 2500);
  Amoeba - 2600 (was 2400);
  Dragon - 2700 (was 2500);
  Hydra - 2700 (was 2500);


VDC X9 V66 B4 / Updated 2021-03-08

- Genetic Mutations tech field cost decreased back from 800 to 650;
- Leaders initial delay restored to 5 turns (was 4);
- Repulsive race leaders hiring chance penalty reduced from -10 to -5;
- Corrected leaders table (position of Rash-iki and PK);
- Leaders skill costs revised (diplomat and trader cost reduced to zero, environmentalist and some other skill costs increased);
- Race cost of +3 prod decreased from 19 to 18 points;



VDC X9 V66 B3 / Updated 2020-11-25

- Genetic Mutations tech field cost increased from 650 to 800;
- Missiles on starbase and missilebase get mirv mod now;
- Space consumption and cost of mirv mod decreased from +100% to +75%;
- Gyro Destabilizer's range increased from supposed 5 to 6 (it was set to 4 in previous update by mistake);
- Plasma Web's range increased from 5 to 6 (each unit of range is 3 squares);
- Corrected tech of ValpraX leader;




VDC X9 V66 B2 / Updated 2020-09-13

- Accommodation of VDC to 1.50.18.1 version of the patch;

- Positronics tech field cost increased from 900 to 1150;
- Charismatic race initial leader hiring chance decreased back from +27 to +25;
- Lucky pick was removed gold and arti bonus given by a script, and cost restored back to 1 point;



VDC X9 V66 B1 / Updated 2020-05-27

- Accommodation of VDC to 1.50.18 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
from new changes:
- Number of freighted population limit increased from 25 to 50;
- Allowed sending the last unit of pop from colony;

VDC changes - 
- Artificial intelligence research cost decreased from 600 to 400 rp;
- Charismatic race bonus increased from +25 to +27;
- Corrected Jarred leader stats;



VDC X8 V65 B3 / Updated 2020-01-27

- reduced bonus of ultra artifacts (orion special), which lucky player gets when taking artifcats world, from +4 to +3;
- corrected pop boom event, which was giving negative growth instead of positive;
- plague event negative growth doubled;
- increased amount of BC bonus of wealthy merchant event;
- am-torpedoes damage increased back from 32 to 36 points; 
- corrected description of stasis field in the help file;


VDC X8 V65 B2 / Updated 2019-12-27

- Accommodation of VDC to 1.50.17 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT

VDC changes - 
- Phase bomb introduced back into the tech tree and placed in Transwarp physics (together with Mauler Device); damage set to 80-160; base space 12;
- Ground Battery space reduced from 810 to 693;
- Space allocation on starbases changed from 30%-10%-15%-45% to 33%-15%-11%-41% for HV-normal-pd-missiles(torpedoes) respectively;
- Star base space increased from 900 to 975, and building cost increased from 400 to 450 BC;
- Battlestation space increased from 2000 to 2100, but cost increased from 1400 to 1500 BC;
- Planetary leaders' commando skill now gives same bonus as ship leaders commando;
- Antaran Titan and Cruiser were added one additional special;
- Added an interface mod, which sorts & colorizes buildings in build menu; 
- Charismatic initial bonus increased from 20% to 25%;
- added a map script, which gives Lucky player gold deposit for homeworld for any race except artifacts hw, while artifact hw becomes ultra artifacts, i.e. gives +4 research instead of +2; cost of lucky increased from 1 to 2 points;
- Tulock leader was deprived of assault shuttles, which were added before;





VDC X7 V64 B2 / Updated 2019-10-13

- Large Scale Construction and Multi-phased Physics tech fields research cost decreased back to 2000 rps;
- Phase Bomb removed from the tech tree;
- Anti-matter bomb damage slightly increased from 30-60 to 30-63;
- Planetary Radiation Shield strength increased from 18 to 20;
- Corrected Chug and Cyber leaders' technologies (last change wasn't applied properly);
- Range-to-hit penalty slightly increased compared to previous change; now it comprises: r0  r1  r2  r3  r4  r5  r6  r7  r8 
                                                                ranged_to_hit_penalty =  0   0  -10 -15 -20 -30 -40 -50 -60; # new range-to-hit penalty
                                                                ranged_to_hit_penalty =  0   0   -5 -10 -20 -30 -35 -42 -50; # previous range-to-hit penalty
                                                                ranged_to_hit_penalty =  0   0  -10 -20 -30 -40 -55 -70 -85; # original range-to-hit penalty

- added a map script that gives lithovore hvg race homeworld size increase by 1: medium becomes large and large becomes huge;
  subterranean combined with tolearant gives gaia hw for free;




VDC X7 V65 B1  Update / Updated 2019-09-15
 
- Accommodation of VDC to 1.50.16 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT

VDC changes - 
- Large Scale Construction tech field research cost increased from 2000 to 2250 rps;
- Multi-phased physics research cost was increased from 2000 to 2250 rps;
- Death Spores technology was used to create new type of bomb instead; Phase Bomb was introduced in the tech tree and placed in multi-phased physics tech field; 
- Range-to-hit penalty of beams was altered to meet new formula of chance to hit, which now always considers range penalty - previously range penalty was completely ignored when there was large BA - BD difference (>99);
- Planetary defense now gets technology specials like Achiless Targeting Unit, Structural Analyzer, High Energy Focus and Range Master Unit when they become known to a player;
- Stasis Field space consumption reduced back from 150 to 100;
- Plasma Web space consumption reduced from 21 to 20;
- Scoutlabs research bonus changed from 1-7-22-37-75-125 to 1-6-24-37-75-150 from frigate to doomstar class respectively;
- Race picks altered - removed +1 extra point from starting points;
- all picks cost moved back to previous values except for lith, which gets further decrease in cost to 24 points and +3 sci - 14 points; AI races adjusted accordingly;
- few Leaders stats updated: Cyber now brings Advanced Damage Control, while Tulock additionally brings Assault Shuttles; position of Bork and Orphus was swapped;



 VDC X6 V64 B1  Update / Updated 2019-07-20

- Accommodation of VDC to 1.50.15 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT

VDC changes - 
- Transwarp Physics research cost decreased from 15,000 to 12,500;
- Temproral Physics research cost decresed from 20,000 to 15,000;
- Stellar Energy Physics research cost decreased from 30,000 to 20,000;
- Armor Barracks became known tech from turn 0; production cost increased from 25 to 30 BC;
- Yota leader was deprived of Armor Barracks, Tachyon Scanner was added instead;
- Feudal governement initial ship production discount decreased from 30 to 27%; however discount now applies to freighters cost too;
- Psionics spying bonus increased from 10 to 12;
- Double cash bonus from scrapping ships enabled;
- Graviton Beam base space consumption decreased from 11 to 10;
- AM-torpedoes damage decreased from 36 to 32 points;
- Starbase specials list updated, check Specials&Hulls section of .xls file for details;

Race Picks altered:
- Added 1 additional point to positive picks;
- +1 food increased from 4 to 5 points;
- +2 food increased from 8 to 9 points;
- cybernetic increased from 5 to 6 points;
- lithovore increased from 25 to 26 points;
- unification creased from 18 to 19;
- +100 pop growth pick changed to +105 growth;
- stock AI races adjusted accordngly, check AI race abilities sheet for details;


VDC X5 V63 B2  Update / Updated 2019-05-31

- Corrected bug with Pirate Cash not to give negative value (was set to 125 instead of 130);
- Space debris bonus set to 75;
- Corrected pop up text of pirate cash/space debris finding on the main screen;
- missile x2 ammo cost reduced;



VDC X5 V63 B1  Update / Updated 2019-05-27

- Accommodation of VDC to 1.50.14 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
  this removes vdc code for defensive antaran titan and destroyer - they no longer get one additional special;

VDC changes - 
- Artificial Intelligence research cost decreased from 650 to 600;
- Transports ships were added extended fuel tanks;
- Feudal & Confederation governments speed of assimilation of enemy pop decreased from 1 pop per 8 turn and 1 pop per 4 turns to 1 per 10 turns and 1 per 5 turns;
- Pirate Cash BC bonus increased from 100 to 130 and Space Debris BC bonus from 50 to 70;
- 'Mineral Deposit' event delay increased from t50 to t75;
- Starbases number of missiles increased by about 25% (takes less space for space calc);
- Civilian buildings armor increased for bombing resistance:
  tritanium  - 150% from base;
  zortrium   - 200% from base;
  neutronium - 300% from base;
  adamantinum- 400% from base;
  xentronium - 500% from base;
- Ground combat mechanics - excessive marines over ship's capacity don't die on a ship capture immediately anymore (cancelled 1.50.7.2 rule);
- Combat mechanics - beam dissipation for high ranges decreased  - was -60% and -65% for range 7 and 8 - became -50% and -60%; this means beam damage for longer distance increased, i.e. beams get lesser dissipation;
- Leader initial offer chance delay decreased from 5 to 4 turns, i.e. leader roll starts from t5;
- AI personalities chances slightly changed;


VDC X4 V62 B13  Update / Updated 2018-11-27

- VDCREG: Genetic Engineering and Genetic Mutation tech fields research cost increased from 400 to 600 and from 650 to 900 rps;
All:
- Galactic Economics research cost decreased back from 15000 to 13500 rps;
- Unification government food bonus decreased from 60 to 55% and Galactic unification food bonus from 110% to 105%;
- Democracy was given 5% starting morale bonus, but research bonus of Federation decreased from 80 to 75%;
- Android Scientist and Android Worker cost restored to 75 and 100 BC respectively;
- Lucky race event roll decreased from 60 to 50 (increases chances of lucky event);
- Some lucky events delay changed;



VDC X4 V62 B12  Update / Updated 2018-11-05

- Scoutlab research points for dectroyer and cruiser class increased from 6 and 19 to 7 and 22 points;


VDC X4 V62 B11  Update / Updated 2018-09-25

- Fixed prewarp techs, drive technology no longer becomes known for prewarp game;
- Added Cryogene code for uncreative via LUA script, i.e. no need to launch cryogene manually;
- Feudal race initial discount for building ships increased from 25% to 30%;
- Android Worker cost decreased from 100 to 75 BC, and android scientist cost decreased from 75 to 50 BC;
- All events probability increased two times (works when events are on); also some events delay revised;
- Lucky race event roll decreased from 80 to 60 (increases chances of lucky event);
- Alternative Defensive fire chances altered: range 5 = 15 squares chance increased from 75 to 100%; 
  range 6 = 18 squares chance decreased from 25 to 0%; range 7 and range 8 keep zero chance;
- overloaded mod space consumption decreased  from 80% to 67% (slightly decreases actual space consumption of weapons since mods are additive, not multiplicative);
- corrected descriptions of some techs;



VDC X4 V62 B10  Update / Updated 2018-06-21

- Missile Base space increased from 500 to 650;
- Assault Shuttles space consumption decreased by 10% from 20 to 18;
- Stasis Field space consumption increased from 100 to 150;
- Bio-Terminator chance decreased from 40 to 35;
- Some ship specials space consumption modified, check 'specials and hulls' section of .xls file for details;




VDC X4 V62 B9  Update / Updated 2018-04-28

- Fixed the bug with High Energy Focus providing wrong damage increase (was set to +50% for heavy beams and +50% for pd whereas it should have been +33% for heavy and +100% for pd as before);



VDC X4 V62 B8  Update / Updated 2018-04-25


- removed democracy moral bonus, but restored research bonus of Federation back to 80%;
- telepathic mindcontrol minimal ship class set to Battleship;
- Bork Leader was restored Recyclotron technology;



VDC X4 V62 B7  Update / Updated 2018-03-08

- Scoutlabs research bonus increased from 1, 5, 17, 37, 65, 101 to 1, 6, 19, 37, 75, 125 for each ships size class respectively; 
- Democracy was added +5 starting moral and +10 moral on Federation; research bonus on Federation decreased from 80 to 70%;
- Democracy pick cost increased from 11 to 12; AI races adjusted accordingly;


VDC X4 V62 B6  Update / Updated 2017-09-28

- Corrected description of Class XII Shield and Ground Batteries in the help file;
- Star Base space increased from 880 to 900;
- Graviton Beam damage increased from 12-24 to 12-25;
- Gauss Cannon damage increased from 24 to 25;
- Overloaded mod of missiles and torpedoes space consumption decreased from 100% to 80%;
- Stasis Field space consumption decreased from 112 to 100;

- Merger utility was removed from the pack until it gets fixed: currently it doesnt support new save format; 



VDC X4 V62 B5  Update / Updated 2017-09-16

- Stellar Converter space consumption reduced from 400 to 370 and miniaturization removed;
- Plasma Torpedo base space consumption reduced from 67 to 65;
- Mauler Device base space consumption reduced from 38 to 37;
- No Range dissipation mod space consumption decreased from 25% to 20%: affects both mauler and plasma torpedo;
- Proton Torpedo base space consumption reduced from 28 to 27;
- Class X shield upgraded to Class XII shield;
- Starbase specials list complitely revised: added damper field, which replaces shields technology when becomes available and added reflection field; multi-wave jammer and range master unit were removed from the list;
- Starbases weapon allocation percentage slightly changed in favour of missiles and torpedoes;
- Star Base and Battle Station weapon space increased from 800 to 880 and from 1950 to 2000 points respectively;
- Star Fortress hull points and armor decreased by 10%;
- Ground Batteries heavy beam space increased from 650 to 800 points (~+20%), and building cost increased from 175 to 200;
- Titan's hull points increased from 930 to 940;
- Damper Field space consumption slightly reduced;





VDC X4 V62 B4  Update / Updated 2017-08-09

- corrected mistake with phasing cloak allowing subspace teleporter on the same ship: they had been made mutually exclusive before;




VDC X4 V62 B3  Update / Updated 2017-08-08

- added correct heroesdata.lbx in package instead of wrong one;
- Graviton Beam base space consumption decreased from 12 to 11;

Race Picks altered:
- democracy decreased from 12 to 11;
- LowG decreased from -12 to -9;
- several Stock AI races changed (Alkari, Gnolam);
- AI additional abilities adjusted;




VDC X4 V62 B2  Update / Updated 2017-07-19

- correcting B1 errors: some of the changes from previous version were not included in X4-V62-B1:
  - Bomber Bays space consumption decreased from 33 to 30;
  - Heavy Fighters hit points increased from 36 to 40;
  - Fusion Bombs damage increased from 10-45 to 15-50;
  - Antimatter Bomb damage increased from 20-60 to 30-60;
  - Neutronium Bomb damage increased from 30-120 to 40-120;
  - Plasma Web was removed miniaturization and space consumption set to 21;

- additionally - 
- Tractor Beams space consumption reduced from 42 to 40;
- Spatial Compressors space consumption reduced from 42 to 40;
- Energy Absorber damage reduction decreased from 33% to 25% (original value); 
- Plasma Torpedo damage increased from 280 to 287;
- Disruptor Cannon space consumption decreased from 28 to 27;
- Mauler Device space consumption decreased from 40 to 38;
- Ground Batteries space for heavy beams increased from 625 to 650;


VDC X4 V62 B1  Update / Updated 2017-07-13

- Accommodation of VDC to 1.50.7.2 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
  From significant balance changes I'd mention the following:
  - adding mods to starbase weapons and allowing torps instead of missiles on starbases/missilebase;
  - torps switch for starbase/missile base was put in ground rules section of vdc config and enabled by default;
  Note that 1.50.7.2 patch breaks couple of VDC legacy code patches: zero-ing space cost of level 3 overloaded mod of missiles on starbases
  & missile base (in result number of missiles drops when you get level 3 mini) and cancels adding two additional specials on starbases; 
  - Removing or adding navigator to a fleet (or when he catches up the traveling fleet) now affects fleet�s speed immediately. Therefore
   it will no longer be possible to direct fleet with a navigator and leave him in the same system. He must accompany fleet in flight to add speed bonus.  
                    

VDC Changes:
- Subspace Teleporter and Phase Shifter technologies were swapped in the tech tree; space consumption for Phase Shifter reduced to zero;
- Advanced Biology research cost increased from 250 to 300 rps;
- Ground Batteries, Starbase and Battle Station's space slightly increased since the weapons now take more space due to mods space counted and 360 degree arc counted instead of 270; Building cost of Battlestation increased from 1300 to 1400 BC;
- Weapon mods available for all defenses include:
  level 1 mods for heavy beams (Ground Battery and Starbases); 
  level 1 & 2 mods for normal and pd beams except that armor piercing mod is not available for pd beams (Ground Battery and Starbases);
  all level 1 mods and enveloping for torpedoes and overloaded for both missiles and torpedoes (Star Bases and Missile Base);
- Shield Piercing mod space cost both for ships and defenses reduced to zero;
- Plasma Cannon base space consumption increased from 23 to 24;
- Plasma torpedoes damage increased from 267 to 280, and additionally plasma torpedoes were given no range dissipation mod back; dissipation is kept at 1 point per square travelled;
- Stasis Field base space consumption decreased from 115 to 112;
- Planetary Flux Shield bonus increased from 27 to 28;
- Assault Shuttles base speed increased by 2 from 6 to 8, what matches bombers speed now;
- Feudal government initial ship building discount changed back to 1/4 from 23/100; additionally fuedal now recieves +5% spying defense bonus on Confederation level; 
- Charismatic race leader hiring bonus increased from +12 to +20%;
- Heavy Armor space slightly decresed for high-tier hulls (made as of reinforced hull);
- Extended Fuel tanks was removed miniaturization, space consumption adjusted accordingly;
- Corrected description of the techs in the help file;



VDC X3 V61 B8  Update / Updated 2017-03-03

- Bomber Bays space consumption decreased from 33 to 30;
- Fighter Garrison number of bombers increased from 3x6 to 3x7;
- Heavy Fighters hit points increased from 36 to 40;
- Fusion Bombs damage increased from 10-45 to 15-50;
- Antimatter Bomb damage increased from 20-60 to 30-60;
- Neutronium Bomb damage increased from 30-120 to 40-120;
- Plasma Web was removed miniaturization and space consumption set to 21;
- Stellar Converter was added miniaturization back and b.s.c. set to 400 (was 315);

Race picks altered:
- +3 science increased from 14 to 15;




VDC X3 V61 B7  Update / Updated 2017-02-02

- Colony Ship building cost increased back to 650 BC (was 615);
- Feudal Government initial discount for building ships decreased from 25% to 23%; Discount on Confederation is kept at 40%;
- Initial number of available leaders for non-repulsive was increased from 10 to 14; Charismatic race bonus decreased from 17 to 13 thus keeping starting number of leaders available for charismatic 27;
- Corrected the changelog adding info about increase of Galactic Economics research cost from 13500 to 15000 in X3-V61-B3 version update info, which was omitted by mistake;



VDC X3 V61 B6  Update / Updated 2017-01-06

- Lucky race roll increased* from 80 to 85; *-corrected descriptio of the change;
- Some events delay increased;
- Fixed Lightning Field getting on starbase with research of wrong tech;
- battle_pods_speed_bonus option removed as it additionally decreases speed of battllepodded ships;
- Raid damage of 1 marine increased back to 30 (15 damage triggers raid-crash rather often);
- Number of stars of small map, which uses medium map's size increased from 20 to 32;
- Finally fixed leaders table; Mentox leader technology changed to hightened intelligence;

Picks cost altered;
- Feudal decreased to -8; AI races adjusted accordingly;



VDC X3 V61 B5  Update / Updated 2016-12-08

- Added new leaders data, which was ommitted by mistake;
- Corrected ground troops armor bonuses, which got wrong bonuses by mistake;




VDC X3 V61 B4  Update / Updated 2016-12-08

- Battlepods cost for Titan class reduced from 1000 to 900 BC;
- Freak_accident event delay increased from t 50 to t75;
- corrected xls file for proton torpedoes change; added info about proton torp change in previous version update log;



VDC X3 V61 B3  Update / Updated 2016-12-05

- Accommodation of VDC to 1.50.6 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
from significant ones I'd mention:

terraformed planets not accepting arriving colonists bug fixed (was introduced in 1.50.1);
added possibility to acquire a shield tech from a scrapped ship;
battlepods no extra speed bonus owing to free space (activated with respective switch);
newly built ships by Warlord have their crew level updated on the turn of the production now;
warlord bonus is now applying to star bases as well as ground batteries (activated with respective switch);
dismissed leaders not getting level up in network game bug fixed; 
fighters now benefit from helmsman;
unlimited number of leaders for a player (activated with respective option);
tractors moved from equipment to weapons category in tech review screen;

VDC Changes:
- Galactic Economics tech field research cost increased from 13500 to 15000; 
- Astro Biology research cost decreased from 80 to 50 RPs;
- Map Generation: GM3 map percent chance of planets updated; new: small - 20%, medium - 56%, large - 21.6%, huge - 2.4%; was: 30%-49%- 18.9%-2.1%; REG map keeps old setting;
- Map Generation: desert climate now produces 0.5 food instead of 1;
- Map Generation: Natives chance increased back from 8% to 9%, while artifacts chance decreased from 6 to 5% for both GM3 and REG;
- Cost of Colony Ship decreased from 650 to 615 BC;
- Feudal Advanced Goverment (Confederation) moral penalty decreased from 20 to 10, i.e. it gives +10 moral when barracks are built; in return ship building discount was reduced back to 40%(from 45%), and science penalty increased from 10 to 15% on Confederation level;
- Galactic Currency Exchange cash bonus increased from 50% to 75%;
- Android Farmers produce +4 food in GM3 version;
- Charismaic race starting pool of available leaders increased from +16 to +17; initial leader chance increased from 10 to 12%;
- Leaders table rearranged once again, changing order of some leaders; check .xls file for details;
- Unlimited number of leaders for a player was set as default setting (can be changed in ground rules section of config);
- Cost of environmentalist skill reduced back to 20 and 40 BC for normal and asterisk skill;
- Lucky race roll decreased from 100 to 80;
- All events delay was revised; check VDC config for details;
- Ship classes base hull space was increased, but battle pods bonus decreased (in result total space unchanged); battle pods cost was adjusted accordingly; check .xls file for details;
- Titans shield multiplier restored as of class 8;
- Raid damage decreased from 30 to 15;
- Defensive Fire mechanics changed to use static values of probability of fire for different ranges instead of old DFR mechanics;
  Probability of fire was set as: range1 =100, range2 =100, range3 =100, range4 =100, range5 =75, range6 =25, range7 =0, range8 =0;
  Each range is 0-3 squares; e.g. range1 is 0-3, range 2 is 4-6, range3 is 7-10 and so on; the count starts from the centre of the ship;
- Beams Arc for 360 degree was decreased from 50% to 33%; 270 degree keeps old value;
- Graviton Beam b.s.c. was increased from 11 to 12;
- Proton Torpedo damage increased from 54 to 60; but base space consumption increased from 25 to 28;


Picks cost altered:
+3 science was increased from 13 to 14 points;




VDC X2 V61 B2  Update / Updated 2016-10-31

- Accommodation of VDC to 1.50.5 version of the patch; full list of changes can be found at: http://moo2mod.com/patch/README_150.TXT
includes:
-  revolutionary planet redrawing bug fixed also known as "freeze bug";
- raid parameters settings;
- defensive fire range and other;

VDC Changes:
- Max damage of raid of 1 trooper was decreased from 50 to 30 points of damage;
- Number of items he can destroy increased from 2 to 3; this change increases the number of items one raider can destroy, but decreases chances to destroy heavy systems and ship engines shields and computers;
- Defensive fire range decreased from 24 squares to 15 squares;
- Heavy Fighters can scramble was enabled as default setting; additionally the 1.50.5 patch fixes the bug of unlimited pd-strikes of heavy fighters, i.e. it is now confined with 2 strikes;
- Beam Computer names were added to config so now it doesn't require proprietary techname.lbx to show correct names; also cloaking field special is now displayed correctly;
- Planetary Radiation Shield blocked damage was corrected; was set 18 points instead of 2;
- Feudal government initial science penalty was decreased from 35% to 30%; ship building discount on Confederation level was increased from 40 to 45%; still keeps 25% on base level;
- Stasis Field space consumption was decreased from 120 to 115 points;
- Gyro Destabilizer was removed miniaturization, but space consumption set as 19 points; was 15 at minimum miniaturization;
- Destroyer space was increased by 2 points from 122 to 124;
- Titan's shield multiplier was decreased, it is treated as class 7 now (was class 8);
- Ships computers and shield hp updated; check ship armor section of the supplied xls. file for details;
- ValpraX leader technology was changed back to Doomstar Construction;

Race costs altered:
- HVG race increased from 3 to 4 points; Stock Bulrathi race now uses excessive points; but in return it gets less points in mutation;




VDC X1 V61 B1  Update / Updated 2016-09-29

- Migration of VDC to 1.50.4.1 patch; all new features and game mechanics changes could be found in in 1.50 patch Manual:   http://moo2mod.com/patch/MANUAL_150.PDF 
and brief description in supplementary file called 'Comprehensive List of Bug Fixes and Rule Changes of 1.5 Patch over VDC Mod' supplied with the VDC package.
- as a side note Feudal has become playable in multiplayer;

Pure VDC Changes:

Tech tree changes -
- TF 29 Engineering was released from known techs on start and was placed as a starting tech field it in biology branch; Hydroponic Farms and Biosphere will become researchable simultaneously;
- Armor Barracks moved back to the tech tree to Advanced Engineering tech field in construction branch; building cost decreased from 30 to 25 BC;
- New tech field named Transwarp Physics and was placed between Hyperspace Physics and Temporal Physics at 15, 000 RP cost;
- Temporal Physics research cost increased from 15,000 to 20, 000;
- Stellar Energy Physics research cost increased from 20,000 to 30,000;
- Stasis Field technology moved back to the tech tree and placed in Temporal Physics, together with Time Warp Facilitator; space consumption is made 120; 
- Mauler Device and Subspace Teleporter moved to Transwarp Physics; Phase Shifter moved to Transwarp Fields;

Balance Changes -
- Subspace Teleporter range increased from 20 to 60 squares; additionally it gains round teleport;
- Fighter Garrison receives third squad of fighters; building cost of FG increased from 80 to 100 BC;
- Interceptors' base space consumption decreased from 15 to 14;
- Shield multipliers for the ships were changed, now Titan is treated as class 8 and Doomstar as class 12; Starbase as class 4, Battlestation as class 7, Star Fortress as class 10; starbases shields hp is calculated as if it already includes shield capacitor x2;
- Starbases classes for specials hp remained as of BB, titan and doomstar, i.e. they get same specials hp as the ships mentioned; however for size class weapons like pulsar and gyro destabilizer it will be one size class less;
- Starbases specials list updated, Time Warp Facilitator replaces Lightning Field, while Lightning Field goes in place of Shield Capacitor;
- Stealth strength made differentiative for stealth devices and race stealth; also race stealth is now cumulative with stealth from technology;
The following numbers apply: Race Stealth  =  7; Cloaking Field =  9; Cloaking Device = 10; Phasing_cloak   = 11; Detection rules did not change - anything what has higher detection range than stealth strength will detect ships at the range of difference of scanning range and stealth strength;
- Corrected spying success threshold, which used to be -80 all the time (thought to be -60 or -55 in case of vdc); now it was made -70; Sabotage chances increased, check 'General' changes sheet of supplied .xls file for details;
- Stellar Converter was removed miniaturization; base space consumption set as 315;
- Black Hole Generator (BHG) is made instastop, like tractors; boarding to Black Hole is banned under new setting; new space for BHG was made 150 for all ships; 
- Federation science bonus increased from 75% to 80%;
- Food Production of Unification increased from 55% to 60% and 105 to 110% for Galactic Unification;
- Supercomputer's building's research bonus increased from 10 RP to 15 RPs per turn;
- Androids building cost made different: Android farmer - 50 BC; Android scientist - 75 BC; Android Workers - 100 BC;
- Mapgeneration: ocean% chance increased from 15% to 16% for GM3 map, while barren chance decreased from 8% to 7%; 
- Mapgeneration: natives % chance decreased from 9% to 8%, while gold chance increased from 4 to 5%; gold and gems together comprise 8%; 
- Increased Base hull space for destroyer and frigate class ships from 115 and 45 to 122 and 49 points of space respectively; building cost additionally adjusted;
- AI race picks revised; check .xls file for details;
- Lucky race events roll increased from 50 to 100;
- Leaders skill costs, which affects hiring cost revised: environmentalist and ordnance cost increased, fighter pilot, farming, helmsman and trader skills cost decreased;
- Chug leader was deprived biomorphic fungi technology;
- Monsters stats revised: new hp for Eel is 2300, Amoeba - 2400 while Dragon, Crystal and Hydra - 2500; Dragon, Crystal and Eel keep Titan size hull class for internals;
  Amoeba and Hydra received new ini:  Amoeba - 28.5; Hydra - 24; Size class of Amoeba was decreased to battleship's, while Hydra's size class increased to doomstar's one; size classes affect hp of internal systems;
 

VDC 60 Update / Updated 2016-07-16

-  Recyclotron moved from Artificial Life to Advanced Manufacturing tech field;
- Androids Farmers moved from Artificial Life to Evolutionary Genetics tech field;
- Assault Shuttles moved from Advanced Manufacturing to Advanced Engineering tech field;
- Armor Barracks moved to known techs and building cost increased from 20 to 30 BC without maintenance cost;
- Prewarp techs were adjusted to meet the change in the tech tree;
- Marine Barracks building cost decreased from 25 to 20 BC and it keeps 1 BC maintenance cost;
- Battle Station's space increased by 20% and building cost increased from 1000 to 1300 BC;
- Titan hull building cost increased from 2300 to 2500 BC;
- Doom Star's base armor and structure points increased by 25%. 
- Mapgen was updated, now -tlowg makes all planets in hw lowg if the race is lowg; previously large arid was keeping normal gravity;

 VDC 59h Update / Updated 2016-05-21

- Warp Dissipator was removed miniaturization, while Extended Fuel Tanks were added; space consumption for Warp Dissipator and Extended Fuel Tanks adjusted;
- Neutron Blaster was removed AF mod, which it got by mistake; building cost slightly decreased;
- Plasma Web space consumption decreased from 35 to 30 points;
- Death Ray building cost decreased;
- Starbase marines restored back to 50; space for weapons increased from 648 to 720;
- Autodone for ships in combat completely disabled;
- Energy Absorber stored energy nullification each new round of combat was disabled, now it keeps previously unused charge infinitely until it gets used;
- ALT+MENLO code bonus increased from 10,000 to 50,000 RP;
- Random events starting turn change corrected; the counter starts from t25 now;
- Cryogen tool updated: fixed the bug of forcing core dumps for tolerant-uncreative races, added removal of weather control for lithovor-uncreative races; removed forcing am-torpedo when player got no missiles in the tech tree;
- Added minor correction for Zero Marines Raid bug fix.
- Leader stats revised: Cyber was deprived of multiphased shield technology while Diablo was added it; Chug was added biomorphic fungi technology;


VDC 59f Update / Updated 2016-03-29

- Neutron Blaster base space consumption decreased from 12 to 11;

Race picks costs altered:
- starting positive picks increased from 33 to 34;
- all production picks increased by 1 to 7-13-19;
- all research picks increased by 1 to 5-9-13;



VDC 59e Update / Updated 2016-03-13

- +0.5 Food race was reverted back to -0.5 food race;
- AI races picks and additional abilities adjusted accordingly;

Race picks costs altered:
- -0.5 food back to old value -5;
- -cash set back to -12;
- HVG cost decreased from 4 to 3 points;



VDC 59d Update / Updated 2016-03-12

- Unification production and farming bonuses decreased back to 55% and 105% for ordinary and advanced governments;
- VDCGM3 climate table updated, decreasing % for oceans and increasing other types; check map generation section of the supplied .xls for details;


VDC 59c Update / Updated 2016-03-05

- Clear Button in ship construction window reverted to original, i.e. no longer removes computers and shields from designs;
- Trade Goods BC output change actually implemented; previous version was missing this change;



VDC 59b Update / Updated 2016-02-28

- Map generation tables further updated - special chances revised: splinter worlds decreased to 0% (was 4%); wormholes decreased from 5% to 4%; Pirate stash increased from 2% to 3%; Gold increased from 3 to 4%; Gems from 2 to 3%; Leaders from 3% to 4% and Artifacts from 5% to 6%;
- Order of turn events changed (Rocco's code):
                   old                             new 
      Research Breakthrough     Technology Stolen
      Evolutionary Mutation       Research Breakthrough
      Hire Officer                      Evolutionary Mutation
      Colonization                     Explore Star
      Explore Star                     Colonization
      Officer Level Report          Hire Officer
      Technology Stolen            Officer Level Report
      Diplomacy Screen             Diplomacy Screen

- Clear Button in ship construction window now removes computers and shields from design too (Rocco's code);
- -Food negative replaced with +1/2 Food pick;
- +Defense pick updated giving new bonuses: +20 defense for 2 pick and +40 defense for 5 picks ( was +15 and +35 defense);
- Number of marines on Star base increased from 50 to 60;
- Trade Goods BC output increased to 75% for odinary races and 150% for expert trader races;
- AI stock races revised;  also the last two scenarios on each difficulty level were unlocked, i.e. all 5 AI scenarios are possible now; for details check the AI race abilities sheet in the supplied .xls file;
- Antarans Fleet Build rate updated - attack delay for average and prewarp game setup was set to t88 and t102 (was t85 and t100 respectively); note that it usually doesn't attack during first two calculation cycles (1 cycle - 5turns); Antaran Resouce Increment for impossible game setup restored to previous value;
- Few antaran ships and antaran starfortress updated;
- CRYOGEN utility was updated to provide holosimulator for non-uni races; also swap gravity generator with else for uncreative hvg races;
- Faina Leader was restored telepathic training technology;

Race picks cost altered:

- -0,5 BC decreased from -12 to -9;
- -0,5 food removed;
- +0.5 food assigned 2 points;


VDC 59 Update / Updated 2016-01-27

- VDCOR project was aborted,
- Climate tables were updated for both VDCREG and VDCGM3 to produce better maps; check for the details in Map generation section of the .xls file. 
- Biomorphic Fungi was restored in the tech tree, increasing farmers output by +1/2 food per farmer on any farming terrain (Rocco's code); additionally it was added to Post Warp game setup;
- Unification production and farming bonus increased from 55% to 60% and Galactic Unification's bonus increased from 105% to 110%;
- Planets production exempt from pollution calculation increased for the following planet classes: medium - 10 (was 9); large - 12 (was 10); huge 15 (was 12); small is kept at 8;
- Plasma Torpedo recharge bug complately fixed; dissipation is set to 1 point of damage per square travelled; no range dissipation mod is not available;
- Graviton Beam  ESD mod damage bonus increased from 50% to 75%; (originally it was 100%, later reduced to 50%, now increased to 75%);
- Starbases were given Battle Scanner and Security Stations on permanent basis thus increasing total number of specials it can hold up to 10; Check new specials list for starbases in specials&hulls section of the .xls file;
- Random events chances increased (success roll set to  128);
- Lucky pick positive chances (success roll set to 50);
- ValpraX leader was deprived of Doomstar construction technology, instead he was added Reflection Field;



VDC 58i Update / Updated 2015-12-13

- Updated description of all fighters and torpedoes speed bonus; the actual speed is higher by 2 than it was reckoned before; erroneous opinion was kept out of first distance, which seems to be by 2 squares less;
- Updated Post Warp game Setup - Robo Miners tech was removed from the list; 
- Missiles permanent defense parameter updated; new values are: nuclear missile +15 (was -10); merculite +35 (was +15), pulson +60 (was +40), zeon +85 (was +70); actual missile's defense parameter is calculated as permanent  defense plus speed multiplied by 5;
- Plasma torpedoes dissipation bug fixed; speed increased from 26 to 28;
- AM torpedoes keep the speed of 24;
- Plasma Cannon base damage decreased back to 22-45;
- Shield Capacitor space consumption decreased for low-tier hulls;
- Housing production output slightly buffed (by 1/41); helping the races without pop growth bonus;
- Random events overhauled: they start to appear from turn 25 instead of turn 50 and event chances doubled; negative events effect decreased, while wealthy merchant bonus increased;
- Lucky player event chances highly increased for the case when events are turned off;
- Yota leader stats revised;



VDC 58h Update / Updated 2015-09-07

- Fixed Post Warp game Setup: the techs available from start in post warp setup are given in the tech tree section of the .xls file (highlighted with blue color);
- Few leaders stats revised (Orphus and Diablo changed again);
- Klackon AI race's additional picks revised: added lhw for first trait;



VDC 58g Update / Updated 2015-08-24

- Corrected work of CRYOGEN tool for current tech tree;
- Fixed crash on capturing Orion, which appeared due to error with the Avenger ship;
- Corrected and updated Avenger ship design;
- Updated Loknar leader to give Dimensional Portal; After capturing Orion you get this tech now;
- Updated Defensive antaran ships and Orion Guardian; now they include nrd mod for particle beam; Offensive antaran ships are kept without nrd mod for particle beam;
- Few other leaders updated; check .xls file for details;
- Bio Terminators base space consumption decreased to 2;
- Extended Fuel Tanks space consumption for high tier hulls increased; check xls for details;
- Scoutlab space consumption for destroyer class ship decreased from 8 to 7;
- Few AI races additional picks updated;





VDC 58f Update / Updated 2015-08-02



- AI race picks and additional abilities revised to meet picks change: 

Race picks cost rolled back to the one which were in 58c; check xls file for details.







VDC 58e Update / Updated 2015-07-28

- AI race picks and additional abilities revised; check .xls file for details;


Race picks updated:

- Starting positive picks increased from 33 to 35;

- +80 pop growth  ->   9; (was 8);
- +100 pop growth ->  12; (was 11);
- +2 Food         ->   8; (was 7);
- +1 prod         ->   7; (was 6);
- +2 prod         ->  13; (was 12);
- +3 prod         ->  19; (was 18);
- Democracy       ->  13; (was 12);
- Lithovore       ->  26; (was 25);
- Creative        ->  14; (was 13). 




VDC 58d Update / Updated 2015-06-26

- Neutronium Bomb damage increased from 30-100 to 30-120 (back to old value);
- Planetary Barrier Shield damage reduction increased from 50 to 64 (back to old value);
- Battle Station scanning range increased from +4 to +5 parsecs;
- Star Fortress scanning range increased from +6 to +7 parsecs;
- Restored medium and small maps sizes to original value (506 width and 400 height);
- Mapgen program -ttiny switch was fixed: it no longer places ungauarded large riches instead of tinies, maximum size for rich planet will be med;
- VDCGM3 doesn;t produce tinies anymore, so -ttiny switch is no longer needed for it; VDCOR or VDCREG still produce tinies;
- few AI races additional (hardcoded) picks were modified; check .xls file for details;
- Faina leader was removed soil enrichment technology, which it kept in previous version by mistake;


Race picks altered:

- +2 food decreased from 8 to 7 points;
- +3 research decreased from 12 to 11 points;



VDC 58c Update / Updated 2015-05-25

- Starting positive points increased by 1, total 33 points;
- AI races updated for picks change;
- Few leaders revised: Faina was deprived of soil enrichment technology and Nimraaz was deprived of commando skill;



Race costs altered:

- +0.5 Food removed, -0.5 Food was restored with the cost of -5;
- -0.5 BC  increased to -12;
- Feudalism decreased to -11;
- Unification increased to 18;
- Lithovore increased to 25;
- Cybernetic increased to 5;



VDC 58b Update / Updated 2015-05-17

- Antarans attack delay set back to 85 and 100 turns for average and prewarp start and 15 turns for advanced start; note that antarans usually don't attack first 2 cycles;
- Antarans resource calculation frequency set back to every 5 turns;
- Antarans Attack Frequency Determinant set to 5;
- AI Stock races updated;
- AI races additional (hardcoded) picks for Hard and Impossible game levels modified; check .xls file for details;
- Race Statistics font decreased, so it holds larger number of records (13 vs 11);
- Corrected race selection and Mutation warnings in Kentext.lbx;

- Race picks altered:
- Max negative set to -12;
- -0.5 Food removed, instead +0.5 Food pick introduced at cost of 1 point; additionally .exe was updated to display correctly +0.5 Food pick in statisticks;
- +2 Food moved back to 8 points;
- -Prod removed, instead +3 Prod introduced at cost of 18 points;
- -Research removed, instead +3 research introduced at cost of 12 points;
- -0.5 BC decreased from -11 to -9;
- Feudalism increased from -11 to -12;
- Democracy increased back to 12 points;
- LowG increased from -11 to -12;
- Uncreative increased from -11 to -12;




VDC 58 Update / Updated 2015-05-12

- Time Warp Facilitator moved one level higher from Temporal Fields to Stellar Energy Physics;
- Fixed cost of several Hyperadvanced techs (the 57f change which was lost in 57g somehow);
- Galactic Economics tech field cost increased from 12,500 to 13,500 RP;
- Antimatter torpedoes damage increased from 32 to 36;
- Plasma Torpedo damage increase from 240 to 267;
- Mauler Device damage increased from 160 to 168;

Race picks altered:
- +2 food decreased from 8 to 7;
- democracy decreased from 12 to 11;





VDC 57g Update / Updated 2015-03-21

- Fixed Phasing cloak weakness to TWF (wasn't working the way intended) - in additional round it was losing it's protection, no matter if the ship fired or not;




VDC 57f Update / Updated 2015-03-20


- Phasing Cloak number of turns of being phase cloaked reduced to first round of combat; on second round the ship equipepd with Ph.Cloak automatically becomes cloaked with improved version of cloaking [+90 defense] no matter if it fired on first round or not; Further passing round without firing will move the ship into improved cloak and will never go to phase cloak; consequently Ph.Cloak is no longer mutually exclusive with TWF;
- All Planetary Shields now block biological weapons;
- Bio Terminator chances increased back to 40%;
- Corrected several hyper advanced techs cost, including hyper advanced power (increased to 10,000);
- Disruptor cannon  space consumption increased back to 28;
- Particle beam was deproved of built-in cont mod, it gets it usual way now (level 1 miniaturization), but additionally it was added no range dissipation mod;  
- fixed the bug of universal antidote being cumulative with microbiotics, which persisted since VDC 53;
- Corrected Yota leader stats;





VDC 57e Update / Updated 2015-03-08


- Cost of colony ship increased back to 650;
- Unification starting bonus increased to 55% and Advanced goverment bonus to 105%;
- Cyber leader deprived of shield capacitor;
- correced log change for 57c - it was missing spatial compressors change;




VDC 57d Update / Updated 2015-03-08


- restored continuous mod to 30%, which changed to old value 35% on previous updated;
- fixed VDC_OR and VDC_REG mapgens for planet % chances;




VDC 57c Update / Updated 2015-03-07

- Fixed MP bug, forcing desynch MP combat on the next turn after someone researched mutation (one exception still exists - warlord ship crews are not updated, but this bug is present in singleplayer too, hopefully will be fixed in future); also fixed the bug, which didn't allow to take improvements of the picks when adjacent negative pick had been taken, e.g. it didn't allow to take +75 offence improvement from +25 offense with -20 defense negative;
- Stealth Field has been added new functionality, now it works same way in combat as cloaking device, but gives 1/2 beam defense bonus [+35] of the cloaking device [+70]; also the name of the technology was modified to cloaking field, to emphasize new functionality; space consumption adjusted accordingly; check .xls file for details;
- Few leaders techs were updated: Mentox receives sci-droids instead of hieghtened intelligence; Cyber receives shield capacitor; Faina receives soil enrichment instead of telepathic traning; 
- VDC_OR and VDC_REG mapgens temporarily lack planet % chance changes I had introduced before; will be updated in a short while;
- Spatial Compressors space consumption decreased from 45 to 42;

Race picks altered:

- +50 defense pick removed, instead +15 defense pick was introduced with cost of 2 points; 




VDC 57b Update / Updated 2015-02-01

- Colony ship building cost decreased from 650 to 600 BC;
- Unification base production and farming bonus restored to 50% (was 60% since v.55);
- Subterranean Farms building cost increased from 100 to 120 BC;
- Artemis System Net building cost decreased from 12k to 11k BC;
- Graviton Beam space decreased from 12 to 11;
- Tractor Beam space decreased from 45 to 42;
- Plasma Cannon damage increased from 22-45 to 23-47;
- Particle Beam damage increased from 20-40 to 20-42;
- Continuous mod space consumption decreased from 35% to 30%;
- Mutation number of picks corrected in all locations of the exe code (not sure if it was ever affecting the game, but still);



VDC 57 Update / Updated 2014-12-10

- Disrupter Canon moved back to Multidimensional Physics tech field; base space consumption decreased from 28 to 25; damage increased from 87 to 90;
- Neutron Bomb damage decreased from 40-120 to 30-100;
- Bombers space consumption reduced from 35 to 33 points;
- Tractor Beams space consumption increased from 40 to 45 points;
- Bio-terminator weapons chances to kill colonists decreased from 40% to 20%; base space consumption increased from 1 to 6 points;
- Stellar Energy Physics and Temporal Physics research cost restored to 20,000 RP once again;
- Wide Area Jammer's fleet bonus increased from 80 to 100; space consumption respectively increased, check special section of .xls file for details;
- Fixed Artemis system net damage: it was set to wrong value by mistake; now each mine inflicts precisely 105 points of damage (was 125) and number of mines vary from 4 to 44 added extra structural damage; building cost increased from 7500 to 12000 BC;



VDC 56 Update / Updated 2014-10-20

- Disrupter Cannon moved one level higher from Distortion Fields to Transwarp Fields; damage and space consumption restored as of previous values;
- Planetary Barrier Shield moved back to Distortion Fields;
- Reflection fields space consumption for higher class ships restored to previous values;
- Leaders table rearranged once again, changing order of leaders; check .xls for details;


VDC 55 Update / Updated 2014-10-17

- IMPORTANT NOTE - due to change in the tech tree CRYOGEN tool for uncreative races may work incorrectly; will be updated in a while;

- Cloaking device moved one level higher to Distortion fields; beam defense bonus decreased from 80 to 70;
- Reflection Field moved higher from Subspace Fields to Quantum Fields; additionally increased the reflection field strength from 18 to 20; space consumption reduced, made same as for hard shields;
- Wide Area Jammer moved from Distortion Fields back to Subspace Fields; space consumption adjusted accordingly;
- Planetary Barrier Shield moved one level lower from Distortion Fields to Subspace Fields;
- Disruptor Cannon moved from Multidimensional Fields to Distortion Fields; damage decreased from 87 to 54, base space consumption decreased from 28 to 17;
- Sensors restored bonus -100;
- Inertial Nulifiers beam defense bonus restored back to 100;
- Bombers hp increased from 24 to 30;
- Interceptors hp increased from 15 to 20 and space consumption reduced from 16 to 15;
- Starbase specials list updated; Achiless Targeting Unit replaces Reflection Field;
- Stellar Converter's space consumption reduced from 500 to 440;
- Unification government base production and food bonus increased from 50 to 60%;
- Charismatic race first hero chances slightly increased;




VDC 54 Update / Updated 2014-09-08

- IMPORTANT NOTE - due to change in the tech tree CRYOGEN tool for uncreative races may work incorrectly; will be updated in short while;

- fixed bug with uncreative race getting only one tech from nuclear fission tech field;
- cloaking Device moved one level lower to Quantum Fields; space consumption for doomstar class slightly increased;
- Wide Area Jammer moved one level higher to Distortion Fields;
- Phased Shifter moved from Quantum Fields to Temporal Physics tech field; additionally space consumption adjusted, check specials & hulls section of the .xls file for details;
- Star Gate moved one level lower to Hyperdimensional Physics tech field;
- Particle Beam moved one level lower to Multidimensional Physics; damage reduced from 20-42 to 20-40;
- Hyper-X Capacitors space consumption corrected;
- Quantum Detonators space consumption reduced to zero;
- Inertial Nulifiers Beam defense bonus increased from 100 to 120;


Race costs altered:

- +1 Research decreased from 5 to 4 points;
- +2 research decreased from 9 to 8 points;
- +75 Attack increased from 8 to 9 points;



VDC 53 Update / Updated 2014-07-09

- Lightning field moved one level higher from Electromagnetic Refraction to Warp Fields;
- Wide Area Jammer moved two levels higher from Warp Fields to Quantum Fields; jamming bonus restored to 140; base space consumption adjusted accordingly, check .xls file for more details;





VDC 52f Update / Updated 2014-05-23

- Colony Ship cost reduced from 800 to 650





VDC 52e Update / Updated 2014-05-23

- Mass Drivers rolled back to 10; 
- Fixed bug with Sensors giving wrong anti-jamming bonus (was still giving -100);
- Missile Design cost for 2 and 15 ammo decreased by 10%;



VDC 52d Update / Updated 2014-05-22

- Advanced Metallurgy research cost decreased from 220 to 200;
- Advanced Chemistry reseach cost decreased from 650 to 600;
- Temporal Fields and Stellar Energy Physics cost increased from 18k to 20k;
- Cost of Colony Ship increased from 550 to 800 B�;
- Zeon Missile hp decreased from 42 to 40 (can be destroyed with 2 pd fusion beams;
- Mass Drivers damage increased from 10 to 12 and base space consumption increased from 10 to 11;
- Positronic Computer's bonus increased from 75 to 85;
- Cybertronic Computer's bonus increased from 100 to 110; 
- Interceptors base hit points increased from 12 to 15;
- Assault Shuttles base hit points increased from 15 to 20;


Race picks cost altered:

- Toleran decreased back to 20 points;
- Cybernetic decreased back to 4 points;
- +2 Research decreased from 10 to 9 points;
- Democracy decreased from 13 to 12 points;
- Unification decreased from 18 to 17 points;



VDC 52c Update / Updated 2014-04-30

- Robotic Factory production output restored back to original values (6-8-10-15-20);
- Autolabs research output restored back to 30 points;

Race picks cost altered:

- +60 growth increased from 5 to 6 points;
- Tolerant increased from 20 to 21 points;
- Cybernetic increased from 4 to 5 points;
- Fantastic trader decreased back to 1 point;
- AI races adjusted.




VDC 52b Update / Updated 2014-04-24


- Moleculatronis tech field moved one level higher from 6500 to 7500 RPs;
- Teaching Methods tech field research cost increased from 2750 to 3150 RPs;
- Colony Base building cost increased back to 200 BC;
- Autolabs research output decreased from 30 to 25 points;
- VDCOR number of planets % changed a little in favour of 5 planet systems;
- VDCGM2 project aborted (was aimed to solve gm3 balance issues of high economy, but didn't get popular);

Race Costs altered:

- Fantastic Trader increased from 1 to 2 points;



VDC 52 Update / Updated 2014-04-20

- Large Scale Construction and Advanced Manufacturing tech fields swapped;
- Auto Repair Units space consumption slightly increased;
- Robotic Factory production output nerfed again to the following values: 6-8-8-12-17;
- Wide Area Jammer main missile evasion bonus decreased from 140 to 120;
- Inertial Nulifier's missile evasion bonus decreased from 54 to 43;
- Sensors anti-missile bonus decreased from -100 to -80;
- ESD mod bonus restored from +50% to +100%; 
- Artemis System Net mines damage decreased from 125 to 105;
- Diablo was added multiphased shields technology instead of deprived one;
- Starbase specials List updated: Reflection Field takes place of Achilless Targeting Unit;




VDC 51 Update / Updated 2014-04-19

- Added an additional executable VDCGM2, which generates exactly 2 planets per system; 
- Lightning Field moved one level lower from Warp Fields to Electromagnetic Refraction tech field;
- Wide Area Jammer moved one level lower from Subspace Fields to Warp Fields;
- Reflection Field moved from Quantum Fields to Subspace Fields; adiitionally reflection field stength reduced from 20 to 18 points;
- Fixed heavy fighters space consumption, which wasn;t adjusted in previous version;
- Robotic Factory production output restored back to original values, ultrapoor world output is left 6, so it's now: 6-8-10-15-20;
- Diablo leader was deprived of Personal shield;
- Antarans attack delay set to 100(94), 115(109) and 20(14) turns for average, prewarp and advanced technology start;
- Antaran's resource calculation frequency increased from every 5 to every 6 turns;
- Antaran's Attack probability significantly reduced;


 


VDC 49b Update / Updated 2014-04-05


- Tech tree restored as of VDC 49;
- 49b keeps the following changes: 
  - Temporal Physics tech fields research cost restored to 15,000;
  - Transwarp Fields research cost increased from 6500 to 7,500;
  - Multi-phased Shields and Shield Capacitor tech swapped; now shield capacitor doubles shield hp, while multi-phased shields recharges shields; space consumption of the techs adjusted accordingle, for more details check .xls file 'Ships&Hulls' section; 
  - Heavy Fighters space consumption reduced from 42 to 40;
  - Phasor beam damage restored back to 14-28 (was keeping old value 13-28);
  - Neutron bomb damage decreased from 40-125 to 40-120;
  - Leaders table;

New changes:
- Interphased Fission research cost decreased back to 10,000 RP;
- Robotic Factory production output decreased from 5-8-10-15-20 to 6-6-8-12-17; building cost remains 80 BC;
- Barrier Shield damage absorbtion reduced from 64 to 50 points;

Note that ESD mod change isn't included in 49b.




VDC 50a Update / Updated 2014-04-05

- fixed refit bug for VDCGM3 version (didn't allow refits of the ships);
- fixed galis leader hp;
- fixed various descriptions in xls. file;
 



VDC 50 Update / Updated 2014-04-04


- Astro Construction, Tectonic Engineering, Superscalar Construction, Planetoid Construction tech fields moved one level higher;
- Electromagnetic Refraction tech field swapped in levels with Advanced Magneto Gravitics;
- Subspace Fields, Quantum Fields, Distortion Fields and Transwarp Fields tech fields moved one level higher;
- Temporal Physics tech fields research cost restored to 15,000;
- Temporal Fields and Stellar Energy Physics research cost increased from 18,000 to 20,000 RPs;
- Gauss Cannon moved from Subspace Fields to Advanced Magneto Gravitics; beam damage decreased from 24 to 20;
- Disruptor cannon moved from Multidimensional Physics to Subspace Fields; Damage decreased from 87 to 43, b.s.c. decreased to 15 points;
- Particle Beam moved from Hyperdimensional Physics to Multidimensional Physics;
- Phase Shifter moved from Quantum Fields to Hyperdimensional Physics; space adjusted accordingly;
- Multiphased Shields and Shield Capacitor tech names! swapped; now shield capacitor doubles shield hp, while multi-phased shields recharges shields; space consumption of the techs adjusted accordingle, for more details check .xls file 'Ships&Hulls' section; 
- Heavy Fighters space consumption reduced from 42 to 40;
- ESD mod bonus restored from +50% to +100%; Artemis System Net damage adjusted accordingly;
- Phasor beam damage restored back to 14-28 (was keeping old value 13-28);
- Neutron bomb damage decreased from 40-125 to 40-120;
- Robotic Factory building cost increased from 80 to 100 BC;
- Leaders Table rearranged once again, some leaders swapped position, few leaders stats revised, check .xls file for more details;




VDC 49 Update / Updated 2014-03-11

- Research cost of Temporal Physics was decreased from 15,000 to 12,500 RP; 
- Advanced Magnetism tech field was moved to level 8 (1150 RP) in force fields branch and renamed to Advanced Magento Gravitics;
- Magnetic Fields tech field renamed back to Advanced Magnetism;
- Tractor Beams space consumption reduced to 40 space;
- Gyro Destabilizer moved back to Advanced Magnetism and restored miniaturization; base space consumption set to 30;
- Radiation Shield moved back to Magneto Gravitics (900 RP);
- BHG was again deprived of miniaturization; will get it back soon;
- Fixed Jump Gate bonus to give correct +4 parsec speed increase;
- Phasing cloak was made mutually exclusive with Subspace teleporter and Phase shifter; space consumption for doomstar increased;
- Nimraaz leader was deprived of researcher skill, instead spiritual leader skill was added;



 VDC 48a Update / Updated 2014-02-25


- Fixed a bug with starbse priority list, which was introduced in previous version; starbase specials set as of 47e (achilles targeting unit is back, while shield capacitor removed);
- Corrected update list for previous version (added disruptor cannon change information);



VDC 48 Update / Updated 2014-02-20

- All tech fields with 3500, 4500 and 6000 RP cost increased to 3750, 5000 and 6500 respectively; 
- Made all techs from Electronics tech field (prewarp) known on start and used the tech field to create another tech field in force fields branch;
- Advanced Magnetism tech field (250 rp) renamed into Magnetic Fields;
- New tech field Advanced Magnetism placed at 400 RP force fields after Magnetic Fields;
- Tractor Beam, Planetary Radiation Shield and Shield Capacitor moved to the new tech field;
- Starbase specials revised: Achiless targeting removed, while Shield Capacitor added; 
- Gyro Destabilizer moved from  Magnetic Fields to Magneto Gravitics; space consumption reduced to 17 points without further miniaturization;
- Tractor Beam space consumption reduced from 48 to 45 points;
- Stealth Field placed back to the tech field at Warp Fields (2000 rp); set new space consumption, check xls file for details; 
- Particle Beam moved from Multidimensional Physics to Hyperspace Physics; damage increased from 20-40 to 20-42; added naturally continuous mod;
- Sensors moved from  Hyperspace Physics to Multidimensional Physics; Scanning range reduced to 11 parsecs;
- Stealth Strength reduced from 12 to 10 points, so that tachyon scanner plus starfortress and neutron scanner plus battlestation can detect stealth at a range of 1 parsec;
- Black Hole Generator recieved miniaturization back;
- Disruptor cannon damage increased back to 87;
- Antimatter torpedoes base space comsumption reduced by 20% from 20 to 16 points;
- Proton Torpedoes space consumption reduced by 17% from 30 to 25 points;
- Leader table updated: changed the order of leaders and some leaders stats revised; check xls for more details; 
- AI ship designs updated (capture theme);

Race costs altered:
- Added 1 point to starting positive picks, which totals to 32 points;
- -Food increased from -4 to -5 points;
- +2 Food cost increase from 7 to 8 points;-
- Democracy increased from 12 to 13 points;
- Unification increased from 17 to 18 points;
- Cybernetic increased from 3 to 4 points;
- Lithovore increased from 23 to 24 points;
- Charismatic increased from 2 to 3 points;

AI stock races updated;




VDC 47e Update / Updated 2014-02-04

- Rolled back ValpraX leader change because of the bug;



VDC 47d Update / Updated 2014-02-04


- Colony ship building cost increased by 10% to 550 BC;
-  Microbiotics and Universal Antidote growth bonus restored to previous values 30 and 50, and removed cumulative bonus;
- Weather Controller building cost decreased from 200 to 180 BC; 
- Charismatic race first leader chances slightly increased (from +5% to +8%);
- Interphased Fission tech field research cost increased from 10 000 to 12 500 RP;
- Bombers and Heavy Fighters hit points increased by 20% from 20 and 30 to 24 and 36 respectively;
- Jump Gate speed bonus increased from +3 to +4 parsecs per turn;
- Tractor Beam's space consumption decreased from 50 to 48 points; also decreased base cost of production;
- Particle beam damage increased from 18-36 to 20-40;
- Troops Rifle bonuses changed from 5-10-20-30 to 7-15-22-30 respectively; 
- ValpraX leader was removed random skills and given fixed skills instead;


VDC 47c Update / Updated 2014-01-13


Race costs altered:
- +100 pop growth increased from 10 to 11 points;
- Subterranean decreased from 9 to 8;
- Rich homeworld increased from 3 to 4 points;
- Large Homeworld decreased from 2 to 1 point;
- Tolerant decreased from 21 to 20 points;
- Democracy decreased from 13 to 12 points;



 VDC 47b Update / Updated 2014-01-13

- No pollution production of different size planets increased from 4-6-8-10-12 to 6-8-9-10-12 points;
- Colony base building cost decreased back to 180 BC;

Race costs altered:

- Tolerant increased from 20 to 21
 



 VDC 47a Update / Updated 2014-01-12

- fixed raid and capture confirmation window timeouts, which were gone on previous update;
- included proton torpedo and disrupor cannon change of the VDC 47 in readme file;


 VDC 47 Update / Updated 2014-01-09

- Completely fixed tractors redrawing bug which crashed the game (it appeared when tractored ship was trying to escape beoynd the range of tractor beam); However another bug is still there - the game might crash when number of beams directed on a single ship exceeds 10 (note that its number of drawn beams, not quantity of tractors in one beam); 
- Tractors introduced back to the tech tree and placed in Warp Fields 2000 RP together with Lightning Field and Planetary Flux Shield; number of beams required to immobilize each type of the hull was set to 1-2-4-8-16-32; note that now it reduces remaining move points of the target ship immediately; space consumption set to 50 and no miniaturization;
- Class XII shield was reduced back to Class X;
- Planetary Flux Shield damage reduction reduced back to 27 points;
- Phasor base space consumption restored to 10 points;
- Colony base building cost increased back to 200 BC;
- Particle beam's base space consumption set to correct value of 9.
- Proton torpedoes damage decreased from 56 to 54;
- Disruptor cannon damage decreased from 87 to 84;


VDC 46e Update / Updated 2013-12-21 -quick update

- Microbiotics and Universal Antidote growth bonuses decreased from 30 and 50 to 20 and 30, but in return made the bonuses cumulative; 


VDC 46d Update / Updated 2013-12-21

- Armor piercing mod space consumption restored back to original value of +50% (was +75%);
- Plasma Web base space consumption decreased from 35 to 30 poitns;
- Disruptor cannon damage increased from 80 to 87;
- Neutronium bomb damage increased from 30-120 to 40-125;
- Death ray damage increased from 60-130 to 60-134; restored natural continuous mod; space consumption increased from 25 to 30 points;
- Temporal Physics research cost restored as of 15 000 RP (was decreased to 12 500 incidentally);
- Security Stations bonus for capture mode was set to correct value of 30 (previously it was using old value of 20);
- Fixed display bug of not showing attacker's ground combat bonus on raid actions;
- Removed necessity to confirm raid and capture actions for defending side; the time-out for combat results window was set same as in auto-combat mode;
- Corrected description of the starfortress change in 45e version; the starfortress building cost was additionally increased to 3000 BC;
- Corrected nuclear missiles hp, which was made 11 instead of 10 incidentally;



VDC 46c Update / Updated 2013-11-21

-leaders table updated (leader with interceptors moved higher in the table);



VDC 46b Update / Updated 2013-11-15

- Feudal race ship building discounts reduced from -33% and -66% on advanced government level to -25% and -40% respectively;
- Colony Bases building cost decreased by 10% from 200 to 180 BC;
- Frigate armor hit points  increased to 5 points ; total hit points are 10 modified by best armor;
- Intercetpor's hp decreased from 15 to 12 hp; 
- Nuclear missile damage increased from 9 to 10 points;
- All monsters hp increased by 10-20% to match nuclear missile new damage; Eel - 2200 hp; Amoeba - 2300 hp; Dragon&Hydra&Crystal - 2400 hp;
- Armor mod of the missiles moved to level 3 miniaturization; all missiles get new hp: nuclear - 10; merculite - 30; Pulson - 36; Zeon 42; which is double with heavy armor mod;
- Shuttles hp decreased to 15 points;
- Phasors damage increased from 13-27 to 14-28; base space consumption incresed from 10 to 11;
- Transports built after researching any stealth facility acquire stealth field and become invisible on the main screen; 
- Spying chances slightly decreased; 
- Nile leader's  skills corrected;  ValpraX leader gets new tech instead of old; check .xls file for details;
- Cryogen tool for uncreative upgraded: now it gives at least one type of pollution cleaner if none; gives at least one type of armor above titanium if none, gives molecular computer if there is no computer higher than positronic; gives mauler device if there is no weapons to get through barrier shield;


Race costs altered:

-  -food decreased to -4 points again;
- creative decreased from 14 to 13 points;


VDC 46a Update / Updated 2013-10-20

- Fixed refit bug for average technology start; needed Advanced Fusion tech field researched for refits; now it is associated with correct tech field (Nuclear Fission);
- Hyper Advanced technology cost increment set back to 10,000 RP per level; starting levels adjusted accordingly;
- Democracy defense agents penalty reduced to -5 on Federation level;
- Eel's hp increased from 1600 to 2000 hp;

Race Picks altered:
 
- food set to -5 points;



VDC 46 Update / Updated 2013-10-17

- Cold Fusion tech field was abolished, instead it moved  to level 4 (250 RP) and renamed into Advanced Fusion; All techs which are placed in this field can be researched simultaneously;
- Augemented Engines were moved to Advanced Fusion tech field; Transport, Colony Ship and outpost were moved to Nuclear Fission tech field; Reinforced hull became known at start;
- Advanced Fusion tech field was used to create one additional tech field in force fields;
- Damper Field and Class 26 shield were assigned to new tech field in force fields called High Absorbtion Fields;
- Temporal Fields were placed after High Absorbtion Fields; Displacement Device  moved to Temporal Fields tech field;
- Phasing Cloak moved back to the tech tree and assigned to Temporal Field; additionally it was made mutually exclusive with Time Warp Facilitator technology and duration of phasing cloak reduced to 1 round;
- Shield Capacitor was moved back to the Electromagnetic Refraction tech field; freeing place for tractors, which will follow up soon;
- Stealth Field removed from the tech tree;
- Energy Absorber was increased in its efficiency from 25 to 33% ;  Note that Hydra will become sturdier;
- Class X shield class was incrased to class XII;
- Planetary Flux shield bonus restored back to 28 points (was 27); 
- Particle Beam and Sensors were swapped in the tech tree;
- Sensors anti-jamming bonus increased from -80 to -100;
- Particle Beam damage decreased from 20-40 to 16-36 points; 
- Fusion beam damage increased from 5-9 to 5-10;
- Graviton Beam damage increased from 10-22 to 12-24 and space increased by 20%;
- Phasor damage increased from 13-26 to 13-27; 
-Plasma Cannon damage incrreased from 22-43 to 22-45; space consumption increased by 9%;
- Proton Torpedoes damage increased from 54 to 56 points;
- Space for destroyer and frigate hulls was increased from 102 and 37 to 115 and 45 respectively; battle podds bonus set strictly to 20% for low tier hulls (previously low hulls were getting higher bonus from battlepods, now it keeps same total space together with battle pods, but allocation of space was re-adjusted in favour of initial space);
- All fighters space consumption revised: Bombers - 35 space (was 40); Hvy Fighters - 42 space (was 48); Interceptors - 16 space (was 13);
- Interceptors health points increased by 50% from 10 to 15 points (since quantity of interceptors will be less due to higher space consumption);
- Missiles hp increased from 9-12-15-18 to 10-15-20-24 respectively;
- Various specials space consumption adjusted; see xls for more details; 
- Leader sequence in leaders table updated; Also some leaders statistics revised - see leaders sheet for more details;
- Marine Barracks building cost decreased from 30 BC to 25 BC;


Race Picks altered:

- food decreased to -4 points;
- cybernetic decreased back to 3 points;
- toleran increased back to 20 points;




VDC 45f Update / Updated 2013-10-03

- Communication technologies command points revised: tachyon communications bonus decreased by 1; hyperspace communication's bonus increased by 1; now they comprise 1 and 5 points respectively;
-Kytryl Leader was deprived of hyper drive, isntead he was added automated repair unit technology;

Race picks costs revised:

- Cybernetic increased from 3 to 4 points; (is now equal to +1 food)
- Tolerant decreased from 20 to 19 points; (cybertol combo stays unchanged)
- -food decreased from -6 to -5 points;



VDC 45e Update / Updated 2013-09-24

- Star Bases specials list revised, autorepair and sheild capacitor removed, instead added structural analyzer and achiles targeting unit; check .xls file for more diteils ( specials& hulls section);
- Star Fortress health points decreased by 25%; the building cost increased from 2500 to 3000 BC;
- Space Scanners, Tachyons Scanners and Neutronium Scanners range increasde by 1 parsecs; now it comprises 3, 5 and 7 parsecs respectively;
- Stealth field's strength increased from 9 to 12; now only Sensors or Neutronium Scanner with Starfortress can detect the stealth;
- Increased starting command points by 1 from 5 to 6;
- Neural Scanner spying bonus increased from 5 to 7 points;
- Corrected/improved description of various things;
- Yota leader was added ordinary production skill;



VDC 45d Update / Updated 2013-09-01

- fixed an error with max negative points  going to -12 in 45c;  was set back to -11; 
- fixed description of Warp Interdictor;
- added notice about several changes of 45c, which were missed in previous readme file. 


VDC 45c Update / Updated 2013-08-25

- Fixed planet capacity to 42 pop Again, fixing the 43 pop bug;
- Compressors, Black Hole Generator, Stasis and Tractors were removed miniaturization; Compressors space consumption decreased to 45 points (and no longer decreases);
- Titan's and Doomstar's shield hp multipliers changed from class 5 and class 7 to class 7 and class 9 respectively;
- Transgenetics tech field research cost decreased from 6000 rps to 5000 rps;
- Warp Interdictor's range decreased from 3 parsec range to 2 parsecs; the building cost decreased from 1500 to 1200 BC;
-  Gold and Gems planetary bonus increased additionally to 10 and 15 BC per turn;
- ECM Jammer space consumption additionally decreased;
- Leaders level 6 experience points decreased from 540 to 480;


Race picks cost altered:
- Cybernetic increased from 2 to 3 points;
- Tolerant decreased from 21 to 20 points;
- Artifact homeworld decreased from 4 to 3 points.



VDC 45b Update / Updated 2013-06-19

- VDCGM2 map generator changed to VDCGM3;
- VDCREG and VDCOR mapgenerator's enhanced: planet probabilities slightly increased;
- Ion cannon hvy mount mod removed;
- ESD bonus of graviton beam and artemis system net mines decreased from 100% to 50%;
- Artemis system net mine damage increased from 105 to 125;
- Proton Torpedo damage increased from 48 to 54;
- ECM Jammer introduced back as a free tech; since it's given from start it doesn't get miniaturization, space consumption adjusted accordingly;
- Phasors and Gauss cannon's base space consumption (b.s.c.) decreased by 10%;
- Disruptor's space consumption decreased from 30 to 28 points;
- Ground Batteries point defense beams were added all available level1 mods;
- Transport's and Outposts building cost restored as of original value of 100 BC;
- Fixed Nimraaz leader's instructor skill bonus;



VDC 45 Update / Updated 2013-05-02

- Pop growth picks restored as of 43e; +127 pop growth removed, added +80 growth;
- Added Damper field special to planetary defenses; the tech works in conjuction with planetary shields replacing shield technology; also works without planetary shields;
- Fixed bug with ground installations still working when they are zero hp left; previously they needed full hp +1 damage to be destroyed;
- Gold and Gems income was increased to 8 and 12 BC per turn;
- Federation cash bonus was increased from 75% to 100%;
- Ion Cannon was added hvy mount;
- Stealth Field and Sheild Capacitor techs were swapped in the tech tree; space consumption adjusted accordingly;
- Neutron Scanner's anti-jamming bonus was increased from -40 to -50;
- Lightning Field space consumption was reduced by about 20%;
- Corrected description of proton torpedoes;
- Lord Brazen's /nohousing switch pop growth bonus removed; now it just turns off the housing;
- Starbases size classes reprogrammed once again, enhanced for modding;
- Set maximum for planet capacity to 42 pop regardless of any conditions, fixing the 43 pop bug;
- updated mapgen program: the -bshowring1,2 command is now set as -bshowringX, where X is the range you want to reval; added -snonatives command, which replaces all natives on the map with gold special; added government type for balance calctulation; 


VDC 44 Update / Updated 2013-03-17

- 80 pop growth pick was removed, instead +127 growth pick was introduced at a cost of 13 points;
- Plasma torpedoes change: decreased range dissipation from 5 to 1 point of damage per square travelled, but removed no range dissipation mod; the base space consumption increased from 60 to 67 points; additionally increased speed by 1 from 23 to 24; note that plasma torpedoes keep the bug - they recharge each round of combat.
- Pulsar damage increased from 8-16 to 12-16;
- Stellar Converter building was added an additional gun, now it got double beam; the cost of building increased by 50% to 1500 BC.
- Patched missile speed function, now transdimensional bombers and heavy fighters speed bonus can be set independently - previously it was bounded with missile speed; transdimensional heavy fighters still keep speed bonus +2, but could be increased to +4 if needed.
- Fixed ordinary assassin skill not working (ordinary skill is the one without asterisk);
- Fixed telepathic skill bug (it was using one level less than actual level of the leader);
- Fixed leaders navigator skill display bug - now it displays correct speed bonus. Note that ordinary skill gives +2 speed bonus for level 5 leaders, while the asterisk skill gives +2 speed bonus for level 4 leaders.
- Psionics moral bonus for dictatorship and feudal governments increased from 10 to 15%;
- Feudal government initial science penalty increased from 30% to 35%;
- Fixed Bork leaders skills, which weren't fixed on previous time; also fixed StepNRazor's skills (the bug occured due to swapping them in the leader's table;
- Few leaders were added some additional skills, check .xls file for more details;



VDC 43e Update / Updated 2013-02-11


- Antaran resource growth multiplier adjusted, offense resource growth  was set same as for defense - in result resource growth slightly increased (was mistakenly thought it was the same value for both, but tured out not to be so);
- Antarans attack delay for advanced start was set to 20-25 turns (ingame figure is 15 but it doesn't attack first one or two cycles); note that on advanced technological start antarans send destroyers from the beginning omitting firgates;
- Antarans low-tier ships time limit was set to the following numbers: stop sending frigates on impossible difficulty - after 30 turns; hard difficulty - after 50 turns; normal difficulty - after 80 turns; stop sending destroyers on impossible difficulty - after 65 turns; hard difficulty - after 80 turns; normal difficulty - after 120 turns;
- Antaran destroyer design revised - removed particle beam pd, instead phasor pd beam without shield piercing mod added, amount of pd beams increased 3 times;
- Included the frigate armor change, which was omitted on previous update;
- Bork leader's skills corrected; 
- Some leaders order in the table changed and the skills/techs adjusted, check xls for more details;
- Removed leaders cost of hire doubling due to megawealth skill;
- Heavy Armor space consumption for Titan and Doomstar classes slightly decreased;
- Starbase specials priority list rearranged once again, removing possibility that multiwave ecm jammer and wide area jammer appear on a starbase simultaneously; for details refer to hulls and specials section of the supplied .xls file;


VDC 43d Update / Updated 2013-01-28


- Antarans attack delay set to 85 turns on average and 100 turns on prewarp start (ingame figures are - 80 and 95);  
- Antarans resource growth for impossible difficulty decreased, i.e. fleet strength with each attack will be increasing more smoothly; additionally changed the antarans ships cost for the same reason;
- AI Ship design tweaked: damper field removed from possible specials, instead TWF added.
- All torpedoes moved to first miniaturization group, i.e. size decrease will be same as of the missiles and beams;
- Fast missile mod's speed bonus increased from 4 to 5. Thus missiles get 21(+1) speed on antimatter drive level (antiblitz measure);
- Antimatter torpdoes base space consumption increased by 10% and speed increased from 19 to 20;
- Advanced Metallurgy research cost decreased from 250 to 220 RPS (antiblitz measure);
- Frigate's base armor and structure decreased back from 5 to 4 points, i.e. 1 nuclear missile will be enough to destroy titanium frigate;
- Restored Destroyers increased space points (102), which was lost at some point before;
- Laser Cannon base space consumption decreased from 10 to 9 (it got bad space values for pd beams with b.s.c. 10 - higher level fusion got more pd beams than laser);
- Continuous mod building cost decreased from +50% to +35% of the beam cost (now is same as space cost);
- Outposts and Transports building cost increased by 20% from 100 to 120 BC (antiblitz measure);
- Fighter garrison building cost decreased from 100 to 80 BC (antiblitz measure);
- Inertial Stabilizer's missile evasion bonus decreased from 33 to 23 points;
- Tachyon Scanners bonus increased from -20 to -30;

- Ships' Crew experience levels for elite and ultra-elite decreased from 500 and 1000 to 300 and 500 experience points respectively;
- Leaders experience levels revised: new levels costs are: level 1 - 0; level 2 - 60; level 3 - 150; (same as old); level 4 - 240; level 5 - 360; level 6 - 540;
- Charismatic race's leader availability bonus increased from +10 to +16 leaders in hiring pool.
- Some leaders order was changed (the order of leaders in the table affects the time, when they become available for hiring), check the xls file for more details;
- Starbase specials priority list revised, see the .xls file for details;
- Planetary flux shield strength decreased by 1 point from 28 to 27 points;
- Heavy Armor space consumption decreased for Battleship and destroyer class ships, check the xls for details.
- Restored changes on planets of VDCREG and VDCOR map generators;


VDC 43c Update / Updated 2012-10-22

- Antarans attack delay set to 75 turns on average and 85 turns on prewarp start (ingame figures are the same - 70 and 80); calculation frequency of resources set to every 5 turns; set highest probability for antarans attack; 
- Added one additional special to defensive antaran Titan and defensive destroyer;
- Some anatarns ships specifications revised - slight changes;
- Restored Cloaking Device beam defense bonus back to original value (80);




VDC 43b Update / Updated 2012-09-24

- Spatial Compressors base space consumption restored back to 50; further update of miniaturization coeficients is planned;
- Cloaking device beam defense bonus decreased from 80 to 50;
- Antarans offensive fleet max limit reduced; couple of ships specifications updated;
- Avenger ship's specification completely revised;
- Antarans attack delay set to 70 turns on average and 80 turns on prewarp start (ingame numbers are 50 and 60, but it doesn't attack first two cycles for unknown reason);
- Antarans frequency of attacks set to every 10 turns after  first attack, also it won't skip attack rounds anymore;



VDC 43 Update / Updated 2012-09-18


- Fixed Antarans Starfortress Structure Hp Bug;
- Completely revised anatarans ships specification;
- Increased build rate and reduced antaran attack delay from 200 and 100 turns from prewarp and average start to 90 and 75 turns respectively;
- Increased max number of antaran offensive and defensive fleet about 3-4 times;
- Increased level 5 miniaturization coefficient for group 2 weapons from 0.4 to 0.5, including ship specials, special weapons like spatial compressors, pulsars, stellar converter, antimissile rockets and torpedoes; thus you have only 4 level of miniaturization for group2 weapons; group 1 includes all beams, missiles, shields and bombs - no change there;
- Increased base space consumption for Spatial Compressors from 50 to 60; With max miniaturization it gets 30 space now (+50% to what it used to be);
- Reduced base space consumption of AM- torpedoes by 10%, speed restored to old value of 19;
- Reflection field strength increased from 15 (original) to 20;
- Pulsar's damage decreased from 8-20 to 8-16;
- Missiles hit points revised; new missile hit points are: nuclear missile - 9 (was 8); merculate missile 12 (was 9); pulson missile - 15 (was 12); zeon missile - 18 (was 16); amor mod doubles hp of the missiles as before;
- Some specials space consumption revised due to increase of miniaturization coefficient;
- Small map and medium map size increased by 1 level; Small map gets same size as medium had before, while medium gets same size as large; number of stars remains old - 18 and 36 respectively.


VDC 42c Update / Updated 2012-08-26

- Fixed Plasma torps fire rate (accidentally came down to old value in 42b);




VDC 42b Update / Updated 2012-08-24

- Fixed Star Bases armor bug for cybernetic race and engineer leader for non-cybernetic;
- Increased restoration rate of internal systems for cybernetic race from 3.3% to 8.25% per 1 combat round; Note that cybernetic race repairs ground installations too; Also note that restoration rate of Autorepair Unit is 2X of that of cybernetic race; 
- Star Bases specials revised, added some new specials, others were removed; check the new priority list in 'Specials and Hulls' section of the xls file;
- Fixed Missile Base number of missiles lessening due to overloaded mod; overloaded mod no longer affects the number of the missiles in missile base;
- Star Fortress space increased from 5000 to 5760; Building cost increased to 2500 BC; 
- Star Base space increased from 600 to 648 points;
- Continuous mod space consumption decreased from 50% to 35%; beams space, which use continous mod, was adjusted accordingly;
- Death Ray was deprived of built-in continuous mod, now it has to enable the mod same way as other beams;
- Artemis System Net introduced back to the tech tree; New damage ranges from 3 to 43 mines; Each mine inflicts 105 points of damage (plus ESD) lessened by the shield or damper field; Chances to hit were revised too: frigate - 10%; destroyer - 20%; cruiser - 30%; battleship-50%; titan-70%; doomstar - 100%; building cost increased to 7500 BC;
- Marine barracks building cost increased from 20 to 30 BC;
- Soil enrichment building cost decreased from 120 to 100 BC;
- xls file was added 'Buildings' sheet, where maintenance cost and building cost of all buildings are specified;
- Food Replicators was removed from the tech tree till it gets fixed;
- AI ship designes were extremely improved; additionally, now they use 150% of the space available for each type of the hull;
- Fighter Garrison restoration frequency of fighters doubled; Increased number of interceptors by 10% (against blitzes); building cost increased from 80 to 100 BC;
- Corrected Wide Area Jammer's missile evasion bonuses - now they comprise +140 for a ship and +80 for the fleet as intended;
- Stabilizer's and Nulifier's missile evasion bonus was adjusted to provide even numbers (increased from 25 to 33 and from 50 to 53 respectively);
- Increased Sensors missile evasion bonus to -80;
- Corrected Displacement Device chances vs missiles and torpedoes;
- Structural Analyzer's bonus decreased from 100% to 60%;



VDC 42a Update / Updated 2012-05-24


- Missiles were added overloaded mod; Overloaded mod itself was moved to the level 3 miniaturization and space consuption increased; 
- Zeon missiles damage increased from 36 to 40 points; now it fits the sequence 18-27-40 where each warhead is stronger than previous warhead by 50%;
- Torpedoes damage revised: am torpedo gets 32 base damage and 48 with overloaded mod; protons - 48 base damage - 72 with ovr mod; plasma torps - 240 base damage - 360 with ovr mod. Check .xls files for more details;
- Given new damage of the missiles and torpedoes planetary shields strength revised: Radiation shield 18 points blocking (was 14); Flux shield 28 points blocking (was 24); Barrier Shield 64 points blocking (was 59);
- Change in the tech tree: Radiation shield moved one level higher to Magneto Gravitics tech field; Multiwave jammer moved to Advanced Magnetism tech field; - Wide Area Jammer swapped with Stealth Field, jamiing ability increased  to 140/80, additionally base space consumption decreased by 35%; ECM Jammer removed from the tech tree;
- Fusion Bombs damage increased from 10-40 to 10-45;
- Miniaturization coefficients for level 4&5 miniaturization of the group 1 weapons was increased from 0.35 and 0.25 to 0.40 and 0.30 respectively; Consequently  lasers and fusion beams base space consumption reduced from 10 to 9 points;
- Marine barracks building cost decreased from 40 to 20 BC;
- Subterranean farms building cost restored to 100 BC;
- Ground Batteries space for heavy beams increased from 400 to 500 points, building cost increased from 150 BC to 175 BC;
- Bioterminators % chance decreased from 50 to 40, solving the fusion bomb bug;
- All Star bases weapons allocation percantage was revised. New weapons allocation % is the following: heavy mount - 33%, normal - 16.67%, pd - 16.67%, missiles - 33%; Also the size class was increased by 1.
- All Star bases recieve new space: Star base - 600; Battle Station - 1500; Star Fortress - 5000; Fixed bug with space calculation for megafluxers on starbases. Previously it used to give old value (25%);
- Missiles stack limit on starbases was increased from 30 to 60 missiles in one stack and number of stacks increased from 3 to 4; each stack becomes 60-missiles stack when number of the missiles exceeds 120;
- Reinforced Hull special was disabled for starbases (health points adjucted accordingly), battle scanner now fits on permanent basis;
- Hyperspace Physics research cost increased from 6000 to 7500 RPS;
- Death Ray damage increased from 60-120 to 60-130;
- Disruptor Cannon damage restroed back to 80 points (was 76);
- PlasmaWeb dissipation fixed: now it dissipates with a rate of -50% damage each round. Damage below 5 is rounded to zero.

- Battle pods bonus reduced from 24% to 20% for high-tier hulls;
- Titan ship's base space increased from 860 to 900 points;
- Stellar Converter's base space consumption increased from 450 back to 500 points;
- Eel's hp increased from 1300 to 1600 points;
- Ships engines base hit points increased in the following manner: Cruiser 12->15; Battleship 18->20; Titan 60->80; Doomstar 120->160;   
- Ion Cannon damage increased from 4-14 to 5-15;
- Sensor's scanning range increased from 9 to 13 parsecs;
- Stealth strength decreased to 9 points; therefore any scanning facility exceeding 9 parsecs range will now decloak the stealth at a range of difference between the scanning range and stealth strength. General formula for detection is the following: detect = scanners range + star bases or battle scanner bonus + ships in movement detect bonus - stealth strength.

Race picks altered:
- Stealth decreased from 6 to 3 points;
- Warlord decresed from 5 to 4 points; 


VDC 41c Update / Updated 2011-11-11


- Fixed bug with plasma torpedoes not firing anything without NRD mod (speed restored to original value) ; damage decreased from 180 to 160 points;
- Nuclear bombs damage increased from 5-15 to 5-20 points;
- Fighter Garrison building cost decreased from 100 to 80 BC;
- Battle pods cost for destroyer class increased by 20 BC (from 60 to 80).



VDC 41b Update / Updated 2011-10-08

- Ion cannon damage deacreased from 5-17 to 4-14 points;
- mapgen program updated: -tgaia command was separated into independent command (previously if tgaia was activated it implied use of fixedhw, now can be applied to random hw); additionally -tgaia doesn't give gaia hw for creative race;
  added -trichhw; -thugehw and -tgoodhw commands: -trichhw makes first planet rich, -thugehw makes first planet huge and -tgoodhw is a combination of -trichhw and -thugehw but additionally makes first planet's climate terran. These commands work independently from fixedhw or flathw, i.e. can be applied to random hw;




VDC 41 Update / Updated 2011-10-07

- Lightning Field moved from Multidimensional Physics to Warp Fields tech field; space consumption remained the same; 
- Antimatter torpedoes damage increased by 20% from 20 to 24 points;
- Inertial Stabilizers missile evasion bonus increased from 25 to 35 points;
- Planetary Radiation Shield's and Flux Shield's strength increased by 1 point (from 13 and 23 to 14 and 24 points respectively);
- All Androids building cost bounded with the cost of spies; now their cost is equal to 100 BC;
- Teraforming cost increase removed, base cost updated to 300BC; now each terraforming cots only 300 BC.
- Updated nohousing switch for +0 growth bonus;
- Reduced maximum combat rounds from 50 to 25;


Race costs altered:

- Artifacts homeworld decreased from 5 to 4 points;




VDC 40b Update / Updated 2011-09-08

- Plasma Torpedoes damage revised: damage decreased from 267 to 180, base space consumption decreased from 80 to 55; still fires every turn;
- Planetary Barrier Shield strength reduced by 1 point from 60 to 59 (to get even figures).
- Specified description of high energy forcus more exactly;



VDC 40 Update / Updated 2011-09-05

- Cold Fusion/Advanced Fusion/Artificial Life tech fields change rolled back;
- Subterranean farms building cost increased from 100 to 120 BC;
- Chug and Yota leaders regained their techs back.






VDC 39 Update / Updated 2011-09-03


- Cold Fusion tech field freed and moved into biology section introducing new tech field: terraforming becomes single, while recyclotron and android farmers moved to new techfield at 1500 RPS, named as 'Environment Engineering';  
- Lightning Field moved one level lower to Multidimensional Physics; additionally space consumption increasde by 20%; 
- Dimensional Portal to access antarans moved one level higher instead to Hyperdimensional Physics tech field;
- Since LF is back in the tech tree, plasma torpedoes rate of fire and space consumption revised: rate of fire doubled, while space consumption increased by 33%;
- Quantum detonator moved from Advanced Fusion to Hyperdimensional Fission tech field;
- Disruptor Cannon damage decreased from 80 to 76 points;
- Death Ray base space consumption increased by 1 point from 25 to 26 points;
- Neutronium Bombs base space consumption increased from 7 to 9 points;
- Temproal Fields research cost decreased to original value - 15,000RPS;
- Atomic Bombs base space consumption deacreased by 1 point from 4 to 3 points;
- Planetary Barrier Shields strength reduced from 64 to 60 points;
- Some specials space consumption revised (slight changes), check .xls file for more details;
- Chug leader was deprived teraforming tech (since teraforming is singleton now); also some other leaders techs revised, see .xls file for more details.



VDC 36i Update / Updated 2011-08-05

- Lightning field put back to the tech tree in Hyperdimensional Physichs tech field;
- Ground Batteries point defense weapons space increased from 120 to 150 points;
- Universal Antidote bug fixed: now it gives correct value of pop growth;

Race costs altered:
- +50 pop growth race increased to +60 growth, cost increased by 1 point;
- Lith cost decreased by 1 point, from 24 to 23 points;
 



VDC 36h Update / Updated 2011-07-11

- New utility, named Cryogen.exe, introduced. It alters tech tree for uncreative races in the generated autosave t0 by adding class 7 shield, hard shields, super computers and antimatter bomb to appear invariably. To enable utility just write it out in dosbox config line, the same way as mapgen.exe; No special switches are needed to enable save altering.
- Particle beam damage increased from 16-40 to 20-40; added heavy mount and autofire mod; base space consumption decreased from 12 to 8 points.
- Fusion beam damage increased from 3-8 to 5-9 points;
- Laser cannon base space consumption increased from 9 to 10 points;
- Fusion bombs damage increased by 10% from 10-36 to 10-40;
- Interceptors, Bombers and Assault shuttles hit points increased by 20%;
- Speed of Heavy Fighters restored back to 8 (on nuclear drive);
- Extended Fuel Tanks base space consumption reduced by 20%;
- Proton torpedoes damage increase, promised in previous version, implemented.
- Planetary Barrier Shield strength increased from 56 to 64 points;
- Starbase space for weapons increased increased from 400 to 500 points;
- Chug leader was given teraforming tech back, also Cassandra and Faina were added telepathic training tech;
- Mapgen program updated:  -tfixedhw switch gives med poor terran as a 5th planet, while -tgaia changes that planet to small gaia for subteranean race or no pop capacity modifiers race. 




VDC 36g Update / Updated 2011-06-18


- Universal Antidote growth bonus decreased from 60 to 50;
- Freighters became known for pre-warp start;
- Nuclear Bombs moved to Physics branch for miniaturization purposes;
- Mass Drivers base space consumption reduced by 10% from 11 to 10 points (back to original value).
- Antimatter Torpedoes speed increased by 2 points (from 19 to 21);
- Proton torpedo damage increased by 2 points (from 30 to 32);
- Plasma torpedoes speed increased by 2 points (from 23 to 25);
- Stellar Energy Physics research cost reduced from 25,000 to 17,500 RPS; (and subsequent hyperadvanced research cost restored to 25.000 rps);
- Stellar Converter base space consumption reduced by 20% (from 550 to 450);
- Black Hole generator space consumption decreased by 10% (from 450 to 400)
- Chug was deprived of terraforming; Houri leader starts from level 2 now; Some other leaders techs revised, check .xls file for more details.
- VDCREG and VDCOR are restored with improved planet generation algorythm.
- Mapgen program WILL BE UPDATED SHORTLY (OLD MAPGEN ATM); New features: -tfixedhw switch now gives small poor gaia as a 5th planet for sub or (sub+smth) and no modifiers races, while tol and aqua races still get med poor terran.


Race costs altered:
- Democracy decreased by 1 point, from 14 to 13;
- Charismatic increased by 1 point, from 1 to 2;
 


VDC 36f Update / Updated 2011-04-14

- Tech tree restored to v.36e except for neural scanner/telepathic training swap.

VDC 36f keeps the following changes from v38:

- Fighter Garison number of fighters increased by 20%: interceptors 2x18 (was 2x15); bombers 2x6 (was 2x5) and heavy fighters 2x5 (was 2x4); building cost of fighter garison reduced to 80;
- Ground Batteries Heavy Mount beams capacity increased by 25% from 400 to 500 points; building cost increased from 150 to 200 BC;
- Mass Drivers damage increased from 8 to 10 but additionaly space consumption increased by 10%;
- Proton torpedoes space consumption restored to previous level (-10%);
- Leaders stats as of v.38 except for Future Matrix leader gets neural scanner instead of telepathic training;
- Updated mapgen; 
- Tolerant race cost - 21 points;

Special Note:
- Missiles space consumption restored to previous values: 9, 10, 12, 14, 15 for 2, 5, 10, 15 and 20 ammo respectively;




VDC 38 Update / Updated 2011-04-03

- Antimissile Rockets moved back to tachyon Physics tech field;
- Corrected position of the Battle Scanner and biosphere in the tech tree;
- Security Station-Range Master Unit swap rolled back;
- Advanced Damage Control moved from Advanced Fusion to Servo Mechanics tech field;
- Swapped position of troop pods and survival pods in the tech tree;
- Leaders techs revised once again, check .xls file for more details;
- corrected error with mapgen fixedhw command: the 5th planet provides correct food output; also 5th planet size increased from small to med for teran, with -tgaia 5th planet will be small gaia;

Race costs altered:
- cost of tolerant reduced by 1 point from 22 to 21 points.



VDC 37 Update / Updated 2011-04-02

- Astro Biology tech field moved to Construction brach, now it constitutes new tech field named Servo Mechanics (250 Rps); comes after Advanced Construction (autofactory);
- Since Astro Biology is no longer, Advanced Biology research cost increased from 250 to 300 RPS;
- Previous Servo Mechanics tech field renamed into Chassis Construction;
- Biosphere (Astrobiology tech field) has become a known tech; Food Replicators were removed from the tech tree;
- Missile Base, Antimissile Rockets, Fast Missile racks moved to new Servo Mechanics tech field (250 Rps);
- Missiles space consumption decreased by 8-10% (reason: No free fast missile rack anymore); New space consumption is 8, 9, 11, 13, 15 for 2, 5, 10, 15 and 20 ammo respectively; 
- Robotics research cost decreased from 600 to 400 Rps;
- Merculate Missile swapped with tritanium armor in the tech tree;
- Base armor points for tritanium armor increased from 100 to 150;
- Range Master Unit's position in the tech tree swapped with Security Station's;
- Neural Scanner and telepathic training positions swapped; telepathic traning spying bonus adjusted, now gives +10; While Neural Scanner bonus decreased to 5;
- Fighter Garison number of fighters increased by 20%: interceptors 2x18 (was 2x15); bombers 2x6 (was 2x5) and heavy fighters 2x5 (was 2x4); building cost of fighter garison reduced to 80;
- Ground Batteries Heavy Mount beams capacity increased by 25% from 400 to 500 points; building cost increased from 150 to 200 BC;
- Mass Drivers damage increased from 8 to 10 but additionaly space consumption increased by 10%;
- Proton torpedoes space consumption restored to previous level (-10%);
- Some leaders were revised: Jarred no longer gives antimissile rockets, but instead gives security stations; Mukir no longer gives range master unit; Drax was added Cyber Security Link tech;
- Mapgen program updated: fixed hw switch doesn't give gaia as 5th planet, but teran, in order to get gaia you need to use additional switch -tgaia; Lowg and Hvg teraforming homeworld bug fixed;
- VDCREG and VDC_OR will be updated shortly...



VDC 36e Update / Updated 2011-03-20

- Mukirr leader was deprived of positronic computer and given rangemaster unit back;
- Nile, Diablo, Kytryl and Tulock start from level 3 now;



VDC 36d Update / Updated 2011-03-16

bugfix:
- Ion cannon base space consumption corrected from 17 to 18 points;



VDC 36c Update / Updated 2011-03-16

- Lightning Field moved to Xenon techs (for it might be a cause for eel not working well);


Race Costs altered:
Omni decreased from 3 to 2 points;


VDC 36b Update / Updated 2011-03-15

- Autofire mod space consumption increased from 50% to 100%;
- All weapons, using autofire mod rebalanced; check xls file for more details;
- Particle beam damage and space consumption revised, new damage is 16-40; b.s.c. is 12;
- Updated .xls file for new weapons stats;
- Corrected all inaccuracies in tech descriptions;



VDC 36 Update / Updated 2011-03-15

- Lightning field removed from the tech tree till it's efficiency can be reduced; Loknar still gives lightning field tech;
- Shield Capacitor moved one level lower to the place of lightning field (Electromagnetic Refraction tech field);
- Class 36 shield changed to Class 26 (damage absorbtion factor reduced);
- Instead multiphased shields bonus increased from 50 to 100%;
- Particle beam completely revised: removed ion cannon properties, added natural shield peircing property and point defense mod; new damage is 16-44; space consumption halved;
- Proton torpedoes revised: damage reduced by 25%; however the fire rate increased by 100%; also increased b.s.c. by 10%;
- Spying formula altered: efficiency of spying 'supposedly' increased;
- Psionics spying bonus restored back to 10;
- Flux shield damage absorbtion factor reduced from 26 to 23 points;




VDC 35c Update /Updated 2011-03-13

- Fixed starbase bug for VDCGM2, other executables will be updated soon;
- Corrected picks costs, which mismatched what they should be;
- fixed laser cannon space consumption, which got changed due to error;
- futher decreased missiles space consumption for high ammo, new consumption is 9, 10, 12, 14 and 15 (previously was 9, 11, 13, 15, 17);
- reduced space consumption of shield capacitor by 20%;
- few leaders techs revised: Mukirr was given positronic computer instead of rangemaster unit; Nile's phasor rifle was swapped for phasor beam;
- Cybersecurity Link spying bonus increased from 5 to 8; 




VDC 35b Update /Updated 2011-02-27

- VDCREG and VDC_OR updated for improved mapgeneration;
- Nuetronium bombs damage decreased from 40-120 to 30-120; base space consumption increased from 6 to 7 points;


Race Costs altered:
- democracy:       14 points;
- Tolerant:        22 points;
- Charismatic:      1 points;
- LowG:             8 points;



VDC 35a Update /Updated 2011-02-14

- Increased spying bonus of Psionics technology by 5, new bonus is 15;
- Removed dimensional portal from Siron leader, and corrected leaders description in .xls file;


VDC 35 Update /Updated 2011-02-13

- Ion Cannon was deprived of autofire modification, however damage increased from 3-15 to 5-17; space consumption reduced to 18 points;
- Particle beam was deprived of natural shield piercing mod;
- Transwarp Fields research cost decreased, new research cost is 6,000 RPs;
- Temporal Fields research cost decreased, new research cost is 17,500 RPs;
- Large Scale construction and Aadvanced Manufacturing tech fields swapped in the tech tree;
- Urro leaders stats revised: researcher skill bonus reduced;

Race costs alterded:

- Tolerant race cost decreased by 2 points from 22 to 20 points;




VDC 34c Update /Updated 2011-01-16

- Missile base capacity altered in order to adjust to new base space consumption of the missiles; New capacity is 400;
- Ground Batteries capacity altered: HV beams Capacity increased from 360 to 400 points; pd beams capacity reduced from 150 to 120 points;


VDC 34b Update /Updated 2011-01-12

- Missiles base space consumption changed: considerably reduced high ammo space consumption. The new consumption correspondence is the following: ammo 2 - 9; ammo 5-11; ammo 10-13; ammo 15-15; ammo 20-17; (used to be 10, 20, 30, 35, 40)
- Ion Cannon minimal damage restored back to 3 points;
- Plasma Torpedoes damage increased from 240 to 267 points (against class 36 shield);
- Mauler Device damage increased from 160 to 180 points (same reason as above);
- Neutronium bomb damage revised: new damage value 40-120;
- Ligtning Field space consumption restored to old values (taking into account new missiles);
- Heavy Armor space consumption reduced by 5%;
- Monster stats revised and documented in the .xls description file;
- Stock race revised once again;

 
Race Costs Altered:
- Aquatic          8 points;
- Charismatic      2 points;
- +75 Beam attack  8 points;
- -Food           -6 points;
- +1 BC           12 points;


VDC 34 Update /Updated 2010-12-26


- Energy Absorber Moved from Matter-energy Conversion tec field to Interphased Fission tech field (10.000 RPs);
- Displacement Device moved moved one level higher to Transwarp Fields (7500 RPs);
- Stasis Field compeletely removed from the tech field until the times when stasis field bug is fixed (Bug:even if stasis field carrier is destroyed the captured ship is realesed, but it cannot move or shoot for the end of the round);
- Multiphased shields hp bonus restored to original value (+50%);
- Some of the beams minimal damage increased by 20-30%, to reduce amount of dissipation;
- Lightning Field base space consumption increased by 20%;
- Scout labs base space consumption for high-tier ships increased by 20-30%;
- MWJ space consumption as opposed to Lightning field's decreased by 20%; check .xls file for more details;
- Damper Field space consumption reduced by 20%;
- mapgen.exe program updated: now it automatically backs up turn 0 save before any teraforming application. The name of the save is reflects date and time it was generated.




VDC 33c Update /Updated 2010-12-16

- Battlepods bonus revised: space bonus decreased from 33% to 24%; Check .xls file for more details;
- Spacial Compressors base space consumption increased by 25%;
- Displacement device base space consumption increased by 20-25%;
- Multiphased Shields base space consumption increased by 50%; 
- Plasma Web base space consumption increased by 15%;
- Nuetronium bombs base space consumption decreased from 7 to 6 points;

Race costs altered:

-Telepathic cost decreased from 8 to 7 points;
- Also some of the stock races revised.



VDC 33b Update /Updated 2010-11-27

- Reinforced Hull bug fixed: in VDC 33 it received increased space consumption - was swapped with space consumption of scout labs.




VDC 33 Update /Updated 2010-11-23


- Recyclotron moved from Advanced Engineering to Artificial Life tech field;
- Heavy Fighters Bays moved one level lower to Advanced Engineering tech field (back to the old place); Simultaneously increased base speed by 2 (from 6 to 8); thus on antimatter level it has speed 14;
- Universal Antidote moved one level lower to Genetic Mutations tech field; simultanously growth bonus decreased from 75 to 60;
- Subterranean Farms building cost decreased to 100BC; 
- Destroyer base hull cost decreased by 10 BC;
- Scoutlabs building cost decreased;
- mapgen fixedhw switch altered: the med poor tundra turns to large tundra;
- The Grak leader tech bonus rolled back: he possesses tachyon communications tech as before.

Race costs altered:
- +70 pop growth changed to +80 pop growth, new cost increased 8 points;
- +100 pop growth increased by 1 points: from 9 to 10 points;
- +2 food cost decreased from 8 to 7 points;
- +2 research cost decreased from 11 to 10 points;
- +0.5 BC cost decreased by 1 points;
- +1.0 BC cost decreased by 1 point;
- cybernetic cost decreased by 1 point;





VDC 32b Update /Updated 2010-11-08

- increased stellar converter's space consumption by 10%.
- +75 defense race bonus decreased back to +50;

Race Costs Altered:
+ 50 defense race cost reduced to 7 points.




VDC 32 Update /Updated 2010-11-05

- The first 6 changes of previous update discarded: full roll-back;
- Recyclotrom Moved two levels lower from Large Scale Contruction to Astro Engineering tech field;
- Heavy Fighter Bays moved one level higher from Astro Engineering to Advanced Manufacturing tech field;
- Core Waste Dumps moved one level higher from Advanced Manufacturing to Large Scale Contruction tech field;
- Subterrenean Farms food output increased from 4 to 6 units; building cost increased from 100 BC to 120 BC, the maintenance cost increased to 3 BC per turn;
- Multiphased Shields shields hp bonus increased from 50% to 100%; space consumption remains the same;
- Shield Capacitor recharge bonus increased to 100% of the maximum strength;
- Plasma Cannon and Plasma Web space consumption reduced by 1 point (less than 5%);
- The Grak leader tech bonus changed: tachyon communications removed, warp dissipator added;

Race Costs Altered:
- +25 defense race is now +35 defense race with cost of 5 points;
- +50 defense race is now +75 defense race with cost of 10 points;
- +1 food cost reduced by 1 points from 5 to 4 points;
- +2 food cost reduced by 1 points from 9 to 8 points;




VDC 31 Update /Updated 2010-10-25

- Microbiotics moved from Genetic Engineering to Artificial Life tech field, simultaneously the growth bonus increased from 30 to 50%;
- Universal Antidote moved from Artificial Life to Evolutionary genetics tech field;
- Telepathic training moved from Artificial Inteligence to Genetic Engineering tech field;
- Rangemaster Unit moved from Artificial Consciousness to Artificial Inteligence tech field;
- Positronic Computer moved one level higher to Artificial Consciousnesstech field, simultaneously attack bonus decreased from 75 to 65;
- Cybersecurity Link spying bonus increased from 5 to 10;
- Battle Pods space bonus increased from 20 to 33%;
- Ion cannon space consumption increased by 10%; damage remains the same;
- Graviton beam damage restored to old value: 6-22 (increased by 10%);
- Plasma Cannon space consumption reduced by 10%;
- Plasma Torpedoes space consumption reduced by 10%;
- Death Ray swapped with Mauler regarding position in the tech tree: Mauler went one level higher, Death Ray one level lower;
- Barrier Shield strength increased by 2 points (back to old value 56);
- Monsters HP increased: Hydra, Dragon, Crystal; Ameoba - 2000 HP; Eel - 1200 hp; crystals and ameoba's number of beams doubled.


Race costs altered:

+50 Attack race is now +75 attack race with cost of 9 points; Remeber the bug: the +25 attack race can't take +50(75) attack improvement via mutation IF the race includes -20 Ship defense negative;
+10 Espionage cost decreased from 3 to 2 points;


bugfix
- VDC_OR.exe was mistakenly deprived of planet construction tech, now it includes this tech;
- Corrected description of Black Hole Generator;



VDC 30 Update /Updated 2010-10-07

- VDCDR3 project aborted;
- Core Waste Dumps swapped back with Recyclotrons;
- 'Minus pop growth' modifier was turned into positive modifier, resulting in +70 growth with the cost of 6 points of the race picks;
- Microbiotics bonus was increased from +25 to +30 growth;
- Armor Piercing weapons space consumption was reduced from 100% to 75% to base space consumption of the weapons;
- Fusion bombs damage was increased from 10-30 to 10-36 points; Now it passes through planetary flux shield until it's supported with class X shield technology;
- Ion cannon stats restored back to old values (damage from 3-14 to 3-15 and b.s.c. back to 20 points);
- Barrier shield building cost restored to old value (500 BC);
- Displacement device success chance decreased from 45 to 40%; space comsumption remained the same;
- Stellar Converter's base space consumption restored to original value (500 points of space);
- Some leaders reviewed: leaders with trader skill were deprifed of thereof. 
- Frigate's base cost decreased by 20% from 40 to 32 BC.


Race costs altered:
- +70 pop growth   6 points;
- Creative        14 points;
- minus prod     -11 points;
- minus cash     -11 points;

All stock races were revised. 




VDC 29 Update /Updated 2010-07-27


- Tectonig Engineering, Astro Construction, Large Scale Construction and Advanced Manufacturing tech fields research cost increased (moved one level higher);
- Teaching Methods tech field moved one level higher to 2750 RPS;
- Galactic Economics tech field research cost increased from 10,000 Rps to 12,500 Rps;
- Evolutionary genetics tech field research cost increased from 1800 to 2000 RPs;
- Microbiotics bonus was decreased from +50 to +25 growth;
- Starbase specials priority altered: Priority#1 list: HVY Armor, Reinf Hull, High Energy Focus, Hard Shield, Multiphased Shields, Jammers, Warp Dissipator, Security Stations; Auxilary Substitution list: Battle Scanner, Shield Capacitor, Lightning Field, Reflection Field, Rangemaster Unit, Transporters.
- Mapgen program updated: -mgrav and hence -mmost switch now applies to urich hvgs too changing planets gravity to normal g.


Race costs altered:

- unification cost back to 17 points;
- Large HW cost back to 2 points;
- +0.5 BC cost increased from 6 to 7 points;
- +1 Research cost      5 points;
- +2 Research cost     11 points;
- Lithovore cost       24 points;





VDC 28 Bugfix (2010-07-20)

Bugfix:
Startbase bug fixed.
Starbase priority list changed: swapped displacement device with security stations.



VDC 28 Update /Updated 2010-07-16

- Introduced two new executables: VDCDR3.exe (uses descent rocks 3 generator) and VDC_OR.exe (uses orange generator);
- Significantly improved Antarans and Guardian's ships stats;
- Monsters strength increased considerably, they are no longer easy victims;
- Changed Star Base specials priority list. Here it is the new list: Priority#1 list: HVY Armor, Reinf Hull, High Energy Focus, Hard Shield, Multiphased Shields, Jammers, Warp Dissipator, Displacement Device; Auxilary Substitution list: Battle Scanner, Security Stations, Lightning Field, Reflection Field, Transporters, Shield Capacitor.
- Advanced Manufacturing tech field research points cost reduced from 1500 to 1200;
- Capsule Construction tech field renamed into Large Scale Construction, and increased research cost to 1500 RPs, all techs, previously at Astro Construction moved to Large Scale construction tech field;
- Ships space capacity changed, now they have starting capacity exactly the same capacity as they had together with battle pods special in 27d; Hull cost adjusted accordingly; for more details check the .xls file  - hulls&specials section;
- Military tactics tech field removed, instead Stellar Energy Physics tech field introduced (25,000RPs);
- Temporal Fields research cost increased from 15,000 RPs to 20,000 RPs;
- Warp Interdictor moved to Astro Construction tech field (2000 RPs) 
- Battle Pods moved to Advanced manufacturing tech field (1200 RPs); Battlepods space bonus reduced from 50 to 20%, building cost increased to 50% of the new hull cost;
- Megafluxer's absolute space bonus retained, consequently %-bonus was decreased from 25% to 16.67%;
- Core Waste Dumps were moved higher from Advanced Manufacturing (1200RPs) to Large Scale Construction tech field (1500RPs);
- Recyclotron was moved one level lower to Advanced Manufacturing tech field (1200RPs);
- Space Academy became a known tech;
- Stellar Converter moved from Temporal Physics (15,000RPs) to Stellar Energy Physics (25,000RPs); The damage was increased from 600 to 1000 points and base space consumption increased from 500 to 600 points;
- Reflection field moved two levels higher from Warp fields, to Quantum Fields (on the place of warp interdictor);
- Shield Capacitor Moved from Electromagnetic Refraction to Warp Fields (on the place of reflection field); space consumption reduced adjusted;
- Hard Shields damage bloking bonus vs beams increased from 3 to 4 points;
- Displacement Device moved back from Transwarp Feilds to Distortion Fields, displacement chance increased from 40 to 45%, space consumption adjusted accordingly;
- Stasis Field's base space consumption doubled, now it consumes 250 space points;
- Barrier SHields strength reduced by 2 points from 56 to 54; Building cost increased from 500 to 800 BC;
- Class XX shield strength increased, now it is class XXXVI field, together with hardshields it completely stops particle beam;
- Ion cannon damage reduced from 3-15 to 3-14 and base space consumption increased by 10%;
- Pulsar Damage increased by 20%;
- Plasma Cannon damage increased from 20-40 to 22-42 points;
- Neutronium bombs damage increased by 10%;
- Disruptor Cannon Damage increased from 72 to 80 points, space consumption increased from 30 to 32 points;
- Death Ray damage increased from 60-110 to 60-120 points;
- Some specials space consumption revised, check .xls file for more details;
- Heroes, which used to have space academy have been deprived of this tech;
- Map Generator program enhanced: the fixedhw command now gives different planets in homeworld, namely: large abu swamp, large abu arid, poor med tundra, poor small gaia.

Race Picks Altered:

- Large HW cost increased from 2 to 3 points;
- Charismatic cost decreased from 2 to 1 point;
- +20 Ground Combat cost decreased from 4 to 3 points;
- Unification cost decreased from 17 to 16;


VDC 27d Update /Updated 2010-05-28


- Point defense beams space consumption reduced by 33%; Now they take 1/3 of the normal space;
- Bombers base hp increased by 33% (from 12 to 16);
- Heavy fighters base hp increased by 25% (from 24 to 30);
- Microbiotics growth bonus increased from 25% to 50%, the lith race, which was underpowered after previous changes now receives an appreciable bonus;
- Universal Antidote growth bonus increased from +50% to +75%;
- Ground Batteries HV mount space increased by 20% from 300 to 360 points;
- Androgena Leader deprived of microbiotics;



VDC 27c Update /Updated 2010-05-17

- Molecular Control tech field moved one level higher to 7500RPs;
- Max Negative value decreased from -12 to -11;

Race cost altered:
- Research back to 6/12;
- Demo back to 13;
- -Food        -5;
- Feudal      -11;
- Uncreative  -11; 



VDC 27b Update /Updated 2010-05-08


- Cyber Security Link moved back to Artificial Consciousness tech field, bonus restored to +5;
- Security Stations moved back to Electronics tech field; Ground Combat bonus remained +30;
- Neutron Blaster base space consumption reduced by 20%;
- Evolutionary Mutation points increased from 4 to 5;
- Some leaders names altered.

Race cost altered:

- Democracy is now 14 points;
- +1 Research       5 points;
- +2 Research      11 points;
- Stealth Ships     6 points;




VDC 27 Update /Updated 2010-05-01


- Cyber Security Link moved from Artificial Consciousness to Moleculatronics tech field; additionally the spying bonus increased from 5 to 10;
- Android Workers moved from Moleculatronics to Trans Genetics tech field;
- Security Stations moved from Electronics to Artificial Consciousness tech field; Additionally ground combat bonus increased from 20 to 30;
- Displacement device moved from Distortions fields to Transwarp fields; Additionally reflection bonus increased from 30 to 40%;
- Black Hole generator space consumption and cost reduced from 750 to 400 points;
- Death Ray base space consumption reduced from 30 to 25 points;
- Warp interdictors maintenance cost reduced from 30 to 20 BC per turn;
- Scoutlabs bonus increased in the following manner: FF-1; DD-5; CA-17; BB-37; TT-65; DS-101; space consumption increased accordingly; check .xls file for more details;
- Battle Station's and Star Fortresses command points increased from 2 and 3 to 3 and 5 points respectively;
- Spying function changed, the sabotage chances increased compared to spying tech chances (ndifference from 70-> to 54); 
- Telepathic race spying bonus increased from 10 to 20 bonus;
- Leaders stats reviewed: some leaders were deprived of their techs: drax, faina, jarred, nhagg. Some other leaders received new stats. Check .xls file for more details;
- tf8 magenerator program updated: the -ssplint command was effectively fixed, now it removes splinter monsters correctly; the -mmonst command was improved, all bad monsters are terraformed to tundra climate; fixedhw command updated: the 5th colony's climate changed to gaia;


Race costs altered:

- -prod :    -9 points;
- -research: -9 points;
- lowG:      -11 points;  



VDC 26d Update /Updated 2010-03-23

- increased initial positive picks by 1 point;
- changed -attack race penalty value from -20 to -25 attack;
- enhanced mapgenerator program (mapgen.exe version 0.22), which includes 3 new commands (switches): -ssplint (removes splinter special completely, replacing it with gems); -sarti (removes free techs from visiting arti planets); -m monst (combination of two switches: -mgrav & -mterraform : sets the monster-rich planet's gravitation to normalG and terraforms it from radiated or toxic to barren and from desert to tundra climates);


Races costs altered accordingly:

- Democracy increased from 12 to 13 points;
- Unification from 16 to 17 points;
- Lithovore from 24 to 25 points;
- Fantastic Trader pick cost decreased from 2 to 1 points.





VDC 26c Update /Updated 2010-02-26


- Removed 'Shading' and 'VSync' functions from the game, which allowed to increase performance (game speed) tremendously; the 'shading' is the black screen pause between game screens, which absorbs up to 2 seconds each time switching the screens, now it's compeltely removed; Great thanks to TF8, who found the way to implement it;
- Range master Unit space consumption reduced by 20%;
- increased max negative value to -12, allowing new race combinations; 

Race costs altered:

Negative picks:
- Feudal is now -12;
- Uncreative    -12;
- LowG           -8;
- -Pop growth    -9;
- -food          -6;
- -attack        -6;

Positive picks:
- +20 Espionage 5 points;
- Omni back to  3 points; Since omni is banned at start anyway, saving 1 point allows to take something additional for 2 points.       



VDC 26b Update /Updated 2010-02-20

- Armor Piercing modification's space consumption decreased from 150% to 100%;
- Gauss Cannon base space consumption increased from 10 to 13 points;
- Evolutionary mutation points decreased by half, now it gives 4 points (can take only +25 beam attack instead of +50);

Race costs altered:
- Artifacts homeworld increased from 4 to 5 points;
- charismatic decreased from 3 to 2 points;
- Omni increased from 3 to 4 points;
- Stealth ships decreased from 6 to 5 points;
- Transdimensional decreased from 8 to 7 points;

Negative picks:
- -ship defense -3
- -ship attack  -5
- repulsive     -5
- lowG          -7
- poor hw       -3
- research      -7



VDC 26 Update /Updated 2010-02-06

- Advanced Feudalism Government's science penalty reduced from 15% to 10%;
- All previous changes in Force Fields branch aborted; Instead Armor Piercing modification's space consumption increased from 50% to 150%;
- Laser Cannon damage increased from 1-6 to 1-7 points;
- Stargate technology moved back to Temporal Physics tech field;
- Barrier Shield strength restored to 56 points;
- Nano Disassemblers efficiency factor increased from 2 to 8;
- Base no pollution production points were additionally increased by 2 points: from 2-4-6-8-10 (pp) to 4-6-8-10-12 (pp) for tiny-small-med-large-huge planets respectively;
- Mukir leader was deprived of cybertronic computer (which he was given by mistake); instead he receives rangemaster unit tech;
- Corrected description of Evolutionary Mutation; 

Race costs altered:
- Creative increased by 1 point: from 14 to 15;
- Tolerant increased by 1 point: from 21 to 22; 



VDC 25 Update /updated 2010-01-19

- Feudalism Government's initial science penalty reduced from 50% to 30% and Advanced Feudalism government's science penalty from 25% to 15% respectively;
- Warp Interdictor& Hard Shields moved one level lower to Subspace Fields tech field; At the same time the Subspace Fields tech field research points increased from 2750 to 3250 RPs;
- Stealth field moved one level lower to Warp Fields (2000RPs);
- Gauss Cannon moved one level higher to Quantum Fields tech field;
- Planetary Barrier Shield moved one level lower, and its strength reduced from 56 to 53 points; together with class 7 shield it stops 60 points of damage;
- Dispacement device base space consumption decreased by 15-20%;
- Quantum Detonators space consumption decreased; check .xls file for mroe details;
- Since Quantum detonators explode factor was decreased, drives hp of frigate and destroyers were increased from 2 and 5 to 3 and 6 points respectively;
- Multiphased shields space consumption decreased by 15%;
- Plasma torpedo base space consumption reviewed. New B.S.C. is 67 points;
- Mauler Device base space consumption increased from 35 to 40 points;
- Corrected description of Gyrodestabilizer;
- All Leaders techs reviewed; they were left only 1 tech each; for more details see the .xls file;
- New VDC mod is now available, namely: VDCforCRE.exe with recyclotron and heavy firghter bays techs swapped in the tech tree;

ALL race costs altered to meet new 40 picks system; Evolutionary Mutation now gives 8 points of race picks advancement. Check the .xls file for details;
Max negative value is still -11 points.



VDC 24 Update /updated 2009-12-25

- Recyclotron from Artificial Life to moved to Astro Construction tech field;
- Universal Antidote moved back to Artificial Life tech field;
- All leaders were revised, check .xls file for more details;
- Subterranean Farms building cost increased from 80 to 100BC;
- Quantum Detonator explode damage multiplier reduced from 3 to 2; also increased selfdestruction probability to 100%, when ship captured by raiders; Space consumption of QD was increased accordingly, check .xls file for detail; 
- Plasma torpedoes base space consumption increased by 25% (from 60 to 75 points);
- Plasma Web damage reduced back to 25-30;
- Gyrodestabilizer space consumption reduced by 10% (from 40 to 36 points);
- VDCGM2B project aborted;

Race costs altered:
- Creative cost of creative pick increased from 8 to 9 points;
- +20 attack race is +25 attack now with the same cost.




VDC23 Update  /updated 2009-12-20

- Recyclotron moved one level higher to Artificial Life tech field; additionally cost of building increased to 150 BC;
- Universal Antidote moved one level lower to Genetic Mutations tech field;
- Some leaders were reviewed (given different techs);
- Corrected description of pulsar;
- Death ray received continuous mod as a first level refinement upgrade as it supposed to have;
- VDCTEST.exe is known as VDCGM2B; while VDCGM2.exe is known as VDCGM2A now.


VDC22 Update  /updated 2009-11-13

- Stargate technology moved from Temporal Physics to Interphased Fission tech field;
- Shield Capacitor moved from Gravitic Fields to Electrmagnetic Refraction tech field; additionally space consumption was reduced by 40%;
- Macro Economics tech field (planetary stock exchange) moved one level higher to 1500 RPs;
- Energy Absorber space consumption reduced by 40%;
- Autorepair unit space consumption reduced by 50%;
- Some other special's space consumption reviewed, check .xls file for more details;
- Interceptors (Fighter Bays) speed increased by 4 and armor by 2.
- Corrected description of Shuttles & Interceptors, added hp information on bombers in help file;
- Pulsar weapons damage increased from 8-12 to 8-16 points (since the space consumption was increased before).  

Race costs altered:
- Increased positive points by 1 point.
- Lithovore:   12 points;
- Tolerant:    12 points;
- Unification:  9 points;
- Creative:     8 points;
- Democracy:    6 points;
- +2 research:  6 points;
- +2 food:      5 points;
- HVG:          2 points; 

'VDCTEST' PICKS ALTERED:
- Dict:         0 points;
- Feudal:     -11 points;
- -Prod:      -11 points;
- -Pop.growth -10 points;         
- Lith:        10 points;
- Tol:         11 points;



21.h Update / updated 2009-11-1

- VDC restored from scratch;
- fixed space points of ground batteries (20.a upgrade has been missed in 21.g version). Now it includes correct value. Also corrected description of the ground batteries in help file.
- new 'VDCTEST' version is available (new picks system) with many strong races nerfed. Check .xls file for more details.



21.g Update / updated 2009-10-31

- vdc 21.f changes aborted, status quo restored as of 21.e version
- fixed spacial compressors bug,  which appeared after changing fighters speed: compressors of the ship on which bombers were pointed did zero damage to them while using compressors manually; unfortuantely the main bug couldn't be fixed at this time: sometimes compressors do zero damage to incoming fighters (all types) in autofire regime. Special note: it seems to ignore interceptors with higher probability than other fighters.
- shuttles recieved original speed, i.e. 4 on base. Check .xls file for details.
- because of compressors bug vdcfast modification doesn't make sense, so decided to exclude it from the patch. I may reintroduce it later when there will be more clarity about compressors workability.
 



21.f Update / updated 2009-10-23

- Increased max positive value by 2 points.
- removed microbiotics tech from leader Urro, which it was given by mistake. 

Race picks altered:
- Subterrenean: 6 points;
- Lithovore:   12 points;
- Tolerant:    12 points;
- Creative:     8 points;
- Food +2:      5 points;  
- Democracy:    6 points;  
- Cash +0.5:    4 points;
- Cash +1.0:    7 points.




21.e Update / updated 2009-10-20

- Increased Damper Field killing factor of troops when using transporter to move marines onto equipped ship from 66% to 95%;
- Class XV shield strength increased to Class XX Shield, now together with hard shields it completely stops ion cannon with high energy focus;
- Plasma Cannon damage changed from 22-38 to 20-40 points;
- Plasma Web damage increased from 25-30 to 25-35 points;
- Kronos (siron) ship leader revised: Lore skill was removed, added famous skill instead; Other expsnsive leaders revised/improved: added some technologies;
- Tachyon and Subspace Communications range revised, they recieve the following command range: tachyons - 6 parsecs; subspace communications - 9 parsecs.



21.d Update / updated 2009-09-24

- fixed bug with ultrarich planets production output in VDCGM2 (from 8 to 7 pp).
- corrected description of tachyon scanner.


21.c Update / updated 2009-09-22

- Inertial stabilizers base space consumption reduced by 16%-20%;
- Graviton beam damage reduced by 10% (from 6-22 to 6-20);
- corrected description of tachyon scanner, which was modified by mistake;
- removed Planet Construction tech from the tech tree in VDCGM2 and VDCFAST.


21.b Update / updated 2009-09-05

- ECM Jammer moved back to Advanced Magnetism tech field, for VDCFAST.exe the previous change left intact; 
- Pulsar moved back to Gravitics tech field (650 RPs) and additionally increased spac consumption from 20 to 25 points. For VDCFAST.exe the placement in the tech tree remained;
- All missiles and fighters speed received original values except for shuttles, which got +2 speed increase. The VDCFAST kept increased fighters speed. Check for the xls. file;
- Biomorphing funji removed from the tech tree.
- Bioterminator efficiency increased from 33% to 50%, also corrected description of it. 


21.a Update / updated 2009-09-01


- ECM Jammer moved to Cold Fusion tech field, which means it will be available for free.
- Pulsar moved one tech lower from Gravitics tech field (650 RPs) to Advanced Magnetism tech field (250 RPs); 
- All missiles hp revised. They receive hp as follows: nuclear - 6; merculate - 9, pulson - 12, zeon 16. The heavy armor mod respectively doeubles the hitpoints;
- All fighters hp decreased by 25% compared to previous increase. The fighters hp are as follows: interceptor - 6, shuttles - 10, bombers - 12, heavy fighters -24 on base (i.e. on tritanium level);
- Lightning field base space consumption decreased. Check the .xls file for more details;
- Corrected description of Tachyon and Subspace Communications;
- Corrected description of Tractor beams;
- Corrected 20.a update information.

Race picks roll back to 19.e version, namely:
- Lith: 11
- Aqua: 5
- Demo: 5
- Dict: -1 
- Feudal: -9
- -Prod: -9
- Creative: 7


20.a Update / updated 2009-08-24

- Artificial life tech field moved one level higher at 1150 RPs (previously was 900);
- Transgenetics tech field moved 2 levels higher at 6000 RPs (previously was 3500);
- All missiles and fighters received +4 to speed.
- Antimatter and plasma torpedoes speed increased by 1 (19 and 23 now);
- All Missiles hp increased by 50%;
- All fighters hp increased by 100%. heavy fighters hp increased by 300%. Check .xls file for details.
- Tachyon and Subspace Communications command range increased to 7 and 13 parsecs respectively.
- Tractor beams space consumption and cost decreased to 120 points.
- Ground Batteries space increased by 50% from 300 to 450 points, particularly hv-mount weapons space increased by 25% (from 225 to 300 points) and point defense weapons space increased by 100% (from 75 to 150 points).


Race Race picks altered:
- Lithovore back to 10 points;
- Dictatorship back to 0;
- feudal government back to -10;
- -prod is now back to -10;
- cost of aquatic reduced from 5 to 4 points.
- cost of demo increased from 5 to 6 points.
- cost of creative reduced from 7 to 6 points;



19.e Update /updated 2009-07-29


- Subspace communications provide 3 command points per starbase instead of 2; Hyperspace communications provide 4 command points.
- max negative value increased to -11

Race Race picks altered:

- Lithovore is now 11 points (was -10);
- Dictatorship is now -1 point (was 0);
- +1.0 BC is now 6 points (was 7);
- -prod is now -9 points (was -10).
- feudal government is now -9 points (was -10).



19.d Update /updated 2009-05-16

- Plasma torpedoes base space consumption increased from 50 tp 60 points;
- Titan's drives base hitpoints increased from 50 to 60 points. 



VDC 19.c Update /updated 2009-05-16

- Tractors beam base space consumption increased to 150 points; 
- Ion cannon space consumption corrected; 
- Fighter hit points needs further checking. 


VDC 19.b Update /updated 2009-05-09

- Planetary Barrier Shield moved back to Distortion Fields (4500 RPs);
- Stealth Filed moved from Electromagnetic Refraction to Subspace Fields (2750RPs), additinally base space consumption was decreased;
- Autolabs building cost decreased from 250 BC to 200 BC.
- Fighters hit points doubled.


VDC 19 Update /updated 2009-04-24

- Galactic Networking tech field back to level 16 at 10,000 RPs;
- Moleculatronics back tech field to level 14 at 6,000RPs;
- Warp Field interdictor moved one level higher at Quantum Fields (3,500 RPs); Bulding cost and maintenance cost increased to 1500 and 30 BC respectively;
- Displacement Device moved one level higher at Distortion Fields (4,500 RPs);
- Planetary Barrier Shield moved from Distortion Fields to Subspace Fields (2750RPs);
- Phasing Cloak and Artemis System net removed from the tech tree altogether (moved to xenon techs);
- Proton Torpedoes damaged decreased from 42 to 40 points, at the same time base space consumption increased from 25 to 28 points;
- Plasma Torpedoes base space consumption decreased from 90 to 50 points;
- Stasis field base space consumption increased from 75 to 125 points;
- Black Hole Generator base space consumption decreased from 950 to 750 points;
- Gaia transformation building cost increased from 300BC to 500BC;
- Ships internal systems base space consumption slightly altered; all values are now provided in the .xls file.

Race picks altered:

- Omni is now for 2 points;
- -ship attack is now -6 points. 



VDC 18 update / updated 2009-02-19

- Electronic Computer bonus increased from 35% to 50%;
- Heavy Armor moved from Superscalar Consrtuction tech field to Robotics tech field. Additionally Heavy Armor space consumption increased by 50%. Building cost increased by 300%;
- Fast Missile Racks Moved frm Robotics tech field to Electronics tech field;
- Battle Stations moved from Astro Engineering to Astro Construction tech field;
- Artemis System Net moved from Astro Construction to SuperScalar Construction tech field.
- Multiwave ECM Jammer moved from Warp Fields to MacroGravics tech field;
- Wide Area Jammer moved back to Warp Fields tech field;
- Pulsar moved one level lower to Gravitic Fields;
- Stealth field moved from Gravitic Fields to Electromagnetic Refraction tech field; Additionally base space consumption was decreased from 60 to 50 points.
- Advanced Government tech field moved back to 4500RPs;
- Moleculatronics tech field moved one level higher at 7500RPs;
- Galactic networking tech field moved one level higher at 15000 RPs;
- Gyro Destabilizer Damage increased from 4-5 to 4-6 points.
- Subterenean farms building cost decreased back to 80 BC. The maintenance cost remained 2 BC per turn;
- Tractor beams base space consumption and cost increased to 50 points;
- bombs damage changed in the following way: nuclear bomb 5-15; fusion bombs 10-30; antimatter bombs 20-60; neutronium bombs 30-100.


VDC 17.b update / updated 2008-12-19
- Advanced Government tech field moved one level higher at 6000RPs;
- Galactic Economics tech field moved two levels higher at 10,000RPs.


VDC 17 update / updated 2008-12-18
- Astro University back to 2000 RPs;
- Macroeconomics back to 1150 RPs;
- Evolutionary Genetics tech field research cost reduced to 1800 RPs;
- Artificial Life back at 900 RPs.
- Telepathic traning bonus back to 5%


Race costs altered:
- +0.5 BC is back to 3 points;
- Creative pick cost back to 7 points.


VDC 16 update / updated 2008-12-03

- Astro University moved 1.5 level higher at 3150 RPs;
- Macroeconomics (Planetary Stock Exchange) moved one level higher at 1500 RPs;
- Evolutionary Genetics tech field moved one level higher at 2000 RPs;
- Artificial Life ech field moved one level higher at 1150 RPs.
- Subterrenean farms building cost increased to 100 BC and maintenance cost to 2 BC per turn.
- Fighter Garrisons efectevness doubled. Now it supprots twice number of fighters. Building cost increased to 100 BC respectively;
- Missile base allocation space doubled. Now it supports twice number of missiles. Building cost increased to 120 BC respectively;
- Troop pods base space consumption decreased;
- Security stations base space consumption decreased.
- Telepathic traning bonus increased to 10%
- Cybersecurity Link bonus decreased to 5%.



VDC 15 update / updated 2008-11-16

- ECM Jammer is back in the tech tree at the place of multiwave jammer (MWJ).
- MWJ moved at Warp fields (2000RPs) at the place of wide area jammer (WAJ). MWJ's base space consumption for BB decreased to 75 points.
- WAJ moved one level higher at 2750 RPs.
- Pulsar Damage increased from 7-12 to 8-12

Race costs altered:
- +0.5 BC is now for 4 points;
- +1 BC is now for 7 points;
- all negatives rearranged to 8/6/4/2 style, for details refer to .xls file.



VDC 14.a update / updated 2008-10-24

- Molecular Manipulation tech field moved back to level 12 at 3500RPs;
- corrected quantum computer description (hit bonus +160).
- Ship drives health points decreased: ff-2 (5); DD-5 (10); CA-12 (15); BB-18 (25) [in brackets previous value]. Titan and Doomstar drives left intact (50 and 120 points respectively); 

Race cost altered:
- Creative pick cost back to 6 points.

updated 2008-11-07
- food +1 cost back to 3 points;
- -50 pop growth decreased to -7.



VDC 14 update/ updated 2008-10-15

- Molecular Manipulation tech field moved to level 11 at 2750RPs;
- Molecular Control tech field moved to level 14 at 6000RPs;
- Ultimate Matter Control tech field moved to level 16 at 10,000RPs;
- Autolabs Building cost increased from 200 to 250 BC;
- Quantum Computer to hit bonus decreased to 160 points.
- Phasor damage increased from 9-26 to 10-26 points;
- Death Ray damage increased from 50-100 to 60-110 points;
- Mauler Device base space consumption restored to 35 points.
- Stellar Converter damage increased from 525 to 600 points;
- Planetary Barrier Shields hit points were increased from 53 to 56.

Race cost altered:
- Creative pick cost increased back to 7 points.


VDC 13 update/ updated 2008-09-24


- Microlite construction moved one level higher (from Nano Technology tech field to Molecualr manipulation tech field). 
  the whole tech field was moved lower in the tech tree to level 12 (3500 RPS)
- Subterenean farms building cost increased from 60 to 80 BC.
- Weather Control building cost decreased from 200 BC to 150 BC.
- Star Fortress building cost increased from 1200 BC to 1600 BC.
- Mauler Device base space consumption was increased to 40 points.

Race picks altered:
the new values of race picks are available in VDC_mod_13.xls file (Picks tab).



12.h update / updated 2008-09-10

- food changed to -6 points.
- poor hw changed to -4 points.
- repulsive changed to -2 points.
- ship defense changed to -4 points.
- low-G changed to - 6 points.
- creative increased to 7 points.



12.g upadate / updated 2008-08-30

Race costs altered:
- cost of uni restored to 7 points.
- cost of +1 prod increased to 4 points.
- cost of +2 prod increased to 7 points.
- cost of lithovore back to 10 points
- cost of subterenean back to 5 points.
- cost of +50 pop decreased to 2 points.
- cost of arti increased to 3 points.


12.f update / updated 2008-08-26

Race costs altered:
- cost of uni restored to 8 points.
- cost of +100 pop growth decreased from 6 to 5 points.
- cost of lithovore decreased from 10 to 9 points
- cost of subterenean increased from 5 to 6 points.
- cost of -spy decreased to -4 points.



12.e update / updated 2008-08-19

- Marine Baracks building cost decreased from 60 to 40 BC.
- Armor Baracks  building cost decreased from 40 to 20 BC.
- Robotic Factory maintenance cost decreased from 2 to 1 BC per turn.
- Subterrenean farms maintenance cost decreased from 2 to 1 BC per turn.
- Pulsar damage increased from 6-12 to 7-12.
- Planetary Flux shield efficiency increased from 20 to 26 points.
- Star Fortress building cost and maintenance cost decreased to 1200 BC and 10 BC respectively (previously was 2000 BC and 12 BC).

Race costs altered:
- cost of uni decreased to 7 points.
- cost of artifacts homeworld decreased back to 2 points.
- cost of repulsive decreased from -4 to -6 points.
- cost of poor hw increased from -4 to -2 points.
- cost of -food increased from -4 to -2 points.
- cost of -cash decreased from -6 to -8 points.



12.d update / updated 2008-07-16
- Android workers moved from Trans Genetics tech field to Moleculatronics tech field

Race costs altered:
- cost of lithovore increased back to 10 points
- cost of creative pick decreased from 7 to 6 points



12.c update / updated 2008-07-11
- Heavy Armor moved to Superscalar Construction field

Race costs altered:
- cost of +1 BC increased from 6 to 7
- cost of artifacts homeworld increased from 2 ti 3 points
- cost of lithovore decreased from 10 to 9 points


12.b update / updated 2008-06-24
- Recyclotron moved from Advanced Manufacturing tech field to Genetic Mutation tech field.
- Automated Repair unit moved back to Advanced Manufacturing tech field.


12.a update / updated 2008-06-23
- Recyclotron moved back to Advanced Manufacturing tech field.
- Automated Repair unit moved to the place of Recyclotron in Advanced Chemistry field.
- Building cost of Subterenean Farms was decreased to 60 BC and maintenance cost to 2 BC per turn.

Race cost altered:
- Aquatic cost increased from 4 points to 5.
- +1 prod and +2 prod decreased by 1 point to 3 and 6 ponts respectively.
- Tolerant increased back to 10 points.


11.0 update / Updated 2008-06-09

- Android farmers, scientists and workers each moved one level higher in the tech tree. Annotation: adroid workers receive morale bonus contrary to original description: http://masteroforion2.blogspot.com/2005/07/master-of-orion-ii-bugs.html 
- Ultrarich class planets output was reduced to 7pp/worker in VDCGM2 mod.
- Health points for ALL Ships engines were increased accordingly: ff-5hp; DD-10hp; CA-15hp; BB-25hp; TT-50hp; Doomstar-120hp. Annotation: reinforced hull triples these values. 

Race Costs altered:
- +2 Food pick cost was decreased from 5 to 4 points.

10.d Update /updated 2008-05-18
- Gyro Destabilizer damage  reduced to 4-5 and base space consumpion increased to 40 points.
- Laser cannon damage reduced to 1-6 points.
- Antimatter torpedoes damage inceased to 20 points and space consumption decreased from 18 to 17 points.
- Proton Torpedoes base space consumpion decreased from 30 to 25 points.
- Disruptor cannon damage was increased to 72 points and space consumption increased to 30 points (previously was 25).
- Plasma Cannon damage increased to 22-38 points.
- Mauler Device was added 'No Range Dissipation' mod and base space consumption reduced from 40 to 35 points.
- Plasma Torpedo base space consumption reduced to 90 points (previously was 100).
- Plasma Web base space consumption increased from 30 to 36 points.


10.c Update /updated 2008-04-23
- All missiles damage increased by 10%. Now one BB is capable of killilng the same tech level BB (without any missile defense) with just one salvo (i.e. with 17 mirv missiles).
- Massdrivers damage increased to 8 points.
- Planetary Radiation Shield strength increased to 13 points.
- Pulsar damage reduced to 6-12 from 12-16.
- Gyro Destabilizer base space consumpion reduced to 36 points (previously was 50).
- Proton Torpedoes base space consumpion decreased from 36 to 30 points.
- Disruptor cannon damage increased to 70 points.
- Mauler Device damage increased to from 133 to 160 points.
- Some leaders characteristics were changed. The Great Leaders have now less initial experience, so they may appear earlier in the game.

Race Costs altered:
- Cost of Tolerant pick was decreased from 10 to 9 points.


10.b Update /updated 2008-04-08
- Pollution Processor moved back to Advanced Chemistry field.
- Corrected description of Disruptor Cannon in 'help' file.
- Robotic Factory building cost decreased to 80 BC (previously was 100).
- Recyclotron building cost decreased to 100 BC (previously was 150).
- Corrected description of Plasma Torpedoes in 'help' file.


10.a Update /updated 2008-04-07
- Stargate technology moved back to Temporal Fields.
- Heavy Armor moved to original position to Advanced Construction field (together with auto factory).
- Core Waste Dumps technology moved to Advanced Manufacturing tech field.
- Recyclotron moved from Advanced Manufacturing tech field to Advanced Chemistry field.
- Pollution Processor moved from Advanced Chemistry field to Molecular Manipulation field.
- Incresed base space points for Doomstar ship from 1300 to 1400 points.
- Reduced cost of battlepods for Doomstar ship from 2500 to 2000 BC.
- Reduced Quantum Computer bonus value to 175 (previously was 180).
- Disruptor damage reduced to 60 points (previously was 80).
- Phasor damage incresed to 26 points (previouasly was 22)
- Gauss Cannon damage increased to 24 points AND additionaly added point defence mount.
- Reflection Field base space consumption and building cost decreased and moved one level higher to Warp Fields.
- Plasma Torpedoe damage increased from 160 to 240 points.
- Black Hole Generator base Space consumption and cost increased to 950 points.


9.0b Update /updated 2008-03-26

- Warp interdictors maintenance cost additionally increased from 10 to 20 BC per turn.
- Artemis System Net maintenance cost decreased to 0 BC per turn
- Galactic Cybernet building cost increased to 300 BC and maintenance cost to 6 BC per turn
- Black Hole Generator moved from Temporal Fields to Ultimate Matter Control field.
- Black Hole Generator's basic space consumption increased to 750 points.
- Particle Beam basic space consumption increased to 30 points and removed point defense mount.
- Increased base drives hit points for Titan and Doomstar ships. The new value is 30 and 60 points respectively.
- Plasma Web damage reduced to 25-30 points (previously was 25-35).
- Pulsar damage increased to 12-16 (previously was 10-16) and basic space consumption decreased to 20 points.
- Gauss Cannon damage increased to 22 points (previously was 20).
- Spatial Compressor damage increased from 25-50 to 40-50.


9.0 Update

- Android Scientists moved one level lower from Evolutionary Genetics field to Artificial Life field.
- Warp Interdictors building cost increased to 1000 BC.
- Heavy Armor moved back to Superscalar Contruction.
- Artemis System Net moved from Superscalar Contruction to Astro Construction field.
- Artemis System Net building cost decreased to 500 BC (previously was 1000) and maintenance cost decreased to 5 BC per turn.
- Galactic Networking Techfield is now for 10,000 RPs and comes later than Moleculatronics.
- Moleculatronic Computer value decreased to 135% (previously was 150%)
- Introduced new beam Computer - Quantum Computer, with value to hit bonus - 180%; It is placed at Galactic Networking field.
- Massdrivers damage decreased back to 7 points

Race Costs altered:

Race picks cost altered:
- Cash +0.5 is back to 3 points  
- Cash +1.0 is now for 6 points 
- Ships +50 Offense is decreased to 4 points
- Ships +50 Defense is decreased to 4 points


8.0 Update
- Android Scientists moved from Genetic Engineering field to Evolutionary Genetics field.
- Universal antidote moved from Evolutionary Genetics field to Artificial Life field.
- Anti-matter Torpedoes moved one level higher to Ion Fission field and damage increased to 18 (previously was 16).
- Shield Capacitor moved from Ion Fission to Gravitic Fields.
- Quantum Detonator moved from Advanced Metallurgy field to Advanced Fusion field.
- Warp Interdictors moved one level higher to Subspace Fields.
- Planetary Flux Shield instead moved one level lower from Subspace Fields to Warp fields.
- Warp Dissipator moved from Warp Fields to Magneto Gravitics.
- Wide Area Jammer moved from Magneto Gravitics to Warp Fields.
- Radiation Shield moved one level lower from Magneto Gravitics to Gravitic Fields.
- Pulsar moved one level higher from Gravitic Fields to Magneto Gravitics.
- Pulsar damage increased from 10-14 points to 10-16 points.
- Massdrivers damage increased to 8 points (previously was 7).
- Laser Cannon Damage increased from 1-5 to 1-7 points.


Race picks cost altered:
- Unification is now for 8 points (previously was 7)
- Low Gravity is now -8 points (previously was -10)


7.0 Update
- Biomorphic Fungi moved to Macrogenetics field
- Subterranean Farms moved to Advanced Biology field
- Android Farmers moved to Genetic Mutationss field
- Android Scientists moved to Genetic Engineering field
- Soil Enrichment moved to Genetic Engineering field

Race picks cost altered:
- Lithovore is now 10 points (previously was 11)
- +100 population growth is now for 6 points (previously was 5)
- Rich Homeworld is now 2 points (previously was 3)
- Cash +0.5 is now 2 points (previously was 3)
- Cash +1.0 is now 4 points (previously was 5)


6.0 Update

- Macrogenetics field is now level 3 with 150 RPs (previously was level 4).
- Advanced Biology field is now level 4 with 250 RPs (previously was level 5).
- Genetic Engineering field is now level 5 with 400 RPs (previously was level 6).
- Genetic Mutation feild is now level 6 with 650 RPs (previously was level 7).
- Artificial Life field is now level 7 with 900 RPs (previously was level 8)
- Subterrenian Farms maintenance cost increased from 2 to 3 BC per turn.
- Planetary Supercomputers maintenance cost increased from 2 to 3 BC per turn.
- Heavy Armor is moved from from Superscalar construction field to Advanced Chemistry field.
- Quantum Detonator moved from Advanced Chemistry field to Advanced Metallurgy field.
- Artemis System Net moved from Planetoid Construction field to Superscalar Construction field.
- Superscalar construction field is now level 12 with 3500 RPs (previously was level 13).
- Core Waste Dumps moved from Tectonic Construction to Molecular manipulation feild.
- Star Gate moved from Temporal Physics field to Hyperdimensional Physics field.
- Dimensional portal moved from Hyperdimensional Physics field to Multidimensional Physics field.
- Fusion torpedoes technology renamed back to anti-matter torpedoes


5.01 Update

- Armor Baracks maintenance cost decreased from 2 to 0 BC per turn
- Corrected description of tractor beams in 'help' file.  